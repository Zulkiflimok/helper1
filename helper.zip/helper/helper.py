# HELPER SELFBOT
'''
Created By: elfoxbsd15

'''
from tmp.important import *

parserr = argparse.ArgumentParser(description='HELPER SB elfoxbsd15')
parserr.add_argument('-t', '--token', type=str, metavar='', required=False, help='Token | Example : Exxxx')
parserr.add_argument('-e', '--email', type=str, default='', metavar='', required=False, help='Email Address | Example : example@xxx.xx')
parserr.add_argument('-p', '--passwd', type=str, default='', metavar='', required=False, help='Password | Example : xxxx')
parserr.add_argument('-a', '--apptype', type=str, default='', metavar='', required=False, choices=list(ApplicationType._NAMES_TO_VALUES), help='Application Type | Example : CHROMEOS')
parserr.add_argument('-s', '--systemname', type=str, default='', metavar='', required=False, help='System Name | Example : Chrome_OS')
parserr.add_argument('-c', '--channelid', type=str, default='', metavar='', required=False, help='Channel ID | Example : 1341209950')
parserr.add_argument('-T', '--traceback', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Using Traceback | Use : True/False')
parserr.add_argument('-S', '--showqr', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Show QR | Use : True/False')
args = parserr.parse_args()


listAppType = ['DESKTOPWIN', 'DESKTOPMAC', 'IOSIPAD', 'CHROMEOS']
settings = livejson.File('tmp/setting.json', True, False, 4)
defaultJson = livejson.File("user.json",True, True, 4)

arif = LINE(settings["email"],settings["pswd"])

for publicKey in arif.talk.getE2EEPublicKeys():
    arif.talk.removeE2EEPublicKey(publicKey)

myMid = arif.profile.mid
programStart = time.time()
oepoll = OEPoll(arif)


bos = settings["thebos"]
own = settings["owner"]
usr = defaultJson["role"]['user']
roomBASE = settings["base"]

apiBE = BEAPI(settings["apiKey"]["BE"])




lambang = '® ' + settings["team"]

bool_dict = {
    True: ['Yes', '✓', 'Success', 'Open', 'On'],
    False: ['No', '✘', 'Failed', 'Close', 'Off']
}

if not settings:
    print ('##----- LOAD DEFAULT JSON -----##')
    try:
        default_settings = arif.server.getJson('https://17hosting.id/default.json');settings.update(default_settings);print ('##----- LOAD DEFAULT JSON (Success) -----##')                       
    except Exception:
        print ('##----- LOAD DEFAULT JSON (Failed) -----##')       

def restartProgram():
    print ('##----- PROGRAM RESTARTED -----##')
    python = sys.executable
    os.execl(python, python, *sys.argv)

def logError(error, write=True):
    errid = str(random.randint(100, 999))
    filee = open('tmp/errors/%s.txt'%errid, 'w') if write else None
    if args.traceback: traceback.print_tb(error.__traceback__)
    if write:
        traceback.print_tb(error.__traceback__, file=filee)
        filee.close()
        with open('errorLog.txt', 'a') as e:
            e.write('\n%s : %s'%(errid, str(error)))
    print ('++ Error : {error}'.format(error=error))


def command(text):
    pesan = text.lower()
    if settings['setKey']['status'] == True:
        if pesan.startswith(settings['setKey']['key'] +  " "):
            cmd = pesan.replace(settings['setKey']['key'] + " ",'')           
        else:cmd = 'Undefined command'           
    else:
         cmd = text.lower()  
    return cmd

def commandMen(msg, text,cmdnya):
    kalera = None
    if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():    
        mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
        mentionees = [mention['M'] for mention in mentions['MENTIONEES']]            
        pesan = text.lower()    
        if myMid in mentionees:
            b = pesan.replace("@" ,'')
            asuuu = b.lower()
            if cmdnya in asuuu:
                ktl = asuuu.split(f"{cmdnya} ")
                tol = asuuu.replace(ktl[0] + f"{cmdnya} ","")
                kalera = tol
    return kalera
def allowLiff():
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {'X-Line-Access': arif.authToken,'X-Line-Application': arif.server.APP_NAME,'X-Line-ChannelId': '1656453408','Content-Type': 'application/json'}
    requests.post(url, json=data, headers=headers)
def sendTemplate(to, data):
    allowLiff()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1656453408-8YbRJm45', xyzz)
    token = arif.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {'Content-Type': 'application/json','Authorization': 'Bearer %s' % token.accessToken}
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def loginFlex(to,sender,userName,loc):
    profile = arif.getContact(sender)
    userpict = "https://obs.line-scdn.net/"+str(profile.pictureStatus)
    if profile.pictureStatus is None:
        userpict = "https://i.ibb.co/bFCr5gB/noavatar.png"
    data = {
      "type": "bubble",
      "size": "kilo",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://www.linkpicture.com/q/RYANS-LOGIN.png",
            "size": "full",
            "aspectRatio": "260:120",
            "aspectMode": "cover",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/5LzVcx3/Perak-Putar.png",
                "size": "full",
                "aspectMode": "cover",
                "aspectRatio": "1:1",
                "animated": True
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": userpict,
                    "size": "full",
                    "aspectMode": "cover"
                  }
                ],
                "paddingAll": "0px",
                "width": "85%",
                "height": "85%",
                "position": "absolute",
                "offsetTop": "7.5%",
                "offsetStart": "7.5%",
                "cornerRadius": "100px"
              }
            ],
            "width": "99px",
            "height": "99px",
            "cornerRadius": "100px",
            "position": "absolute",
            "offsetTop": "10px",
            "offsetStart": "10px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": userName.title(),
                "size": "xs",
                "weight": "bold",
                "color": "#ffffff"
              }
            ],
            "width": "130px",
            "height": "25px",
            "position": "absolute",
            "offsetTop": "29px",
            "offsetStart": "117px",
            "paddingAll": "5px",
            "justifyContent": "center"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/6bSgwXg/Andes-Logins.png",
            "size": "full",
            "aspectRatio": "260:120",
            "aspectMode": "cover",
            "animated": True,
            "position": "absolute",
            "offsetStart": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [],
            "width": "111px",
            "height": "21px",
            "offsetStart": "140px",
            "position": "absolute",
            "offsetTop": "87px",
            "cornerRadius": "4px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "line://nv/QRCodeReader"
            }
          }
        ],
        "paddingAll": "0px"
      }
    }
    sendTemplate(loc,{"type": "flex", "altText": "Selfbot Login", "contents": data})
def geTreply(msg):
    kalera = None
    if msg.relatedMessageId != None:
        rhmnirza = arif.getRecentMessagesV2(msg.to, 1001)
        for arifblek in rhmnirza:
            if msg.relatedMessageId == arifblek.id:
                kalera = arifblek
                break
    return kalera


def geTmention(msg):
    if msg.contentMetadata is not None:
        if 'MENTION' in msg.contentMetadata.keys():
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mntn = mention['MENTIONEES']
            target = []               
            for mention in mntn:
                if mention["M"] not in target:target.append(mention["M"])               
            return target
        else:return None    


def splitdel(text, list):
    apatuh = MySplit(text,range(1,len(list)+1))
    b = []
    for c in apatuh.parse():
        b.append(list[int(c)-1])
    return b

def debug():
   a = time.time()
   b = arif.getProfile()
   c = time.time() - a
   d = time.time() - a
   return "%s ms♪" % (round(c * 1000,2))

def runTime():
    a = time.time() - programStart
    return format_timespan(a)

def accepted(located):
    arif.acceptChatInvitation(located)

def rejected(located):
    arif.rejectChatInvitation(located)

def leaveed(located):
    arif.deleteSelfFromChat(located)

def finded(enmy):
    tmn = arif.getAllContactIds()
    if enmy not in tmn:
        arif.findAndAddContactsByMid(enmy)
    else:pass

def kicked(located, enmy):
    arif.deleteOtherFromChat(located, [enmy])

def invited(located, enmy):
    finded(enmy)
    arif.inviteIntoChat(located, [enmy])

def covernyaa(mid): 
    if mid is None:
        mid = arif.profile.mid
    profileDetail = arif.getProfileDetail(mid)
    params = {'userid': mid, 'oid': profileDetail['result']['coverObsInfo']['objectId']}
    url = arif.server.urlEncode(arif.LineObsDomain, '/myhome/c/download.nhn', params)
    return url

def checkScreen(name):
    var = check_output(['screen -ls; true'], shell=True)
    if '.'+name+'\t(' in var.decode('utf-8'):
        return True
    else:
        return False

#def loginselfbot(msg,to,sender,userName,userJson,app):
#    if userName not in os.listdir('user'):os.system("mkdir user/{}".format(userName))
#    random.seed = (os.urandom(1024))
#    randomName = ''.join(random.choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") for i in range(6))
#    win = (f'DESKTOPWIN\t7.7.0\t{randomName}10\t10;SECONDARY',f'DESKTOPWIN\t7.3.0\t{randomName}10\t10;SECONDARY',f'DESKTOPWIN\t7.2.0\t{randomName}10\t10;SECONDARY',f'DESKTOPWIN\t7.5.0\t{randomName}9\t10;SECONDARY',f'DESKTOPWIN\t7.4.1\t{randomName}8\t10;SECONDARY',f'DESKTOPWIN\t7.4.0\t{randomName}7\t10;SECONDARY')
#    desktopwin = random.choice(win)
#    if app.lower() == "chrome":
#        appName = "CHROMEOS\t2.4.3\tChrome OS\t1;SECONDARY"
#        nheader = "CHROMEOS"
#    if app.lower() == "win":
#        appName = desktopwin
#        nheader = "DESKTOPWIN"
#    if app.lower() == "mac":
#        appName = "DESKTOPMAC\t6.7.2\tMAC\t10;SECONDARY"
#        nheader = "DESKTOPMAC"
#    userJson['appType']  = appName
#    params = {
#        "appname": appName,
#        "country": "JP",
#        "apikey": "2be06c9c2d014950911660e74e53cbae"
#    } 
#    if userJson['authToken'] == '' and userJson["cert"] == "":
#        userJson['json'] = {
#            "setting": "user/{}/setting.json".format(userName),
#            "listset": "user/{}/listset.json".format(userName),
#            'position':'user/{}/position.json'.format(userName)
#        }
#        r = requests.get("https://api.chstore.me/v1/lineqr",params=params)
#        qr = r.json()
#        dd = "【 LOGIN 】"
#        dd += "\nType: Selfbot"
#        dd += "\n⇒User: @!"
#        dd += f"\n⇒Name: {userName.title()}"
#        dd += f"\n⇒Header: {nheader}"
#        dd += "\n⇒Note: Check My Pc"
#        dd += f"\n\n® {settings['team']}"
#        arif.sendTag(to,  dd ,[sender])
#        aa = "【 LOGIN 】"
#        aa += "\nType: Selfbot"
#        aa += "\n⇒User: @!"
#        aa += f"\n⇒Name: {userName.title()}"
#        aa += f"\n⇒Header: {nheader}"
#        aa += f"\n⇒IP: {qr['result']['ip']}"
#        aa += "\n⇒Note: Type This Link"
#        aa += f"\n\n® {settings['team']}"
#        arif.sendTag(sender,  aa ,[sender])
#        arif.sendMessage(sender, f"{qr['result']['qrlink']}")
#        arif.sendImageWithURL(sender,str(qr["result"]["qrcode"]))
#
#        rr = requests.get("https://api.chstore.me/v1/lineqr",params=params)
#        qr = r.json()
#        pincode = apiBE.lineGetQrPincode(qr["result"]["session"])
#        arif.sendTag(to,f"Your Pin: {pincode['result']['pincode']} @!",[sender])
#        arif.sendTag(sender,f"Your Pin: {pincode['result']['pincode']} @!",[sender])
#
#        auth = apiBE.lineGetQrAuth(qr["result"]["session"])
#        token = auth["result"]["accessToken"]
#        cert = auth["result"]["certificate"]
#        login = LINE(token,appType=userJson['appType'])
#        arif.sendTag(to,"Please Wait For Login @!",[login.profile.mid])
#        userJson['authToken'] = token
#        userJson['cert'] = cert
#        time.sleep(0.5)
#        if checkScreen(userName) == True:
#            os.system('screen -R {} -X quit'.format(str(userName)))
#            os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
#        else:
#            os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
#        time.sleep(3)
#        if checkScreen(userName):
#            bb = "【 LOGIN 】"
#            bb += "\nType: Selfbot"
#            bb += "\n⇒User: @!"
#            bb += f"\n⇒Name: {userName.title()}"
#            bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
#            bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
#            bb += "\n⇒Note: Success Login Sb"
#            bb += f"\n\n® {settings['team']}"
#            arif.sendTag(to, bb ,[login.profile.mid])
#        else:
#            bb = "【 LOGIN 】"
#            bb += "\nType: Selfbot"
#            bb += "\n⇒User: @!"
#            bb += f"\n⇒Name: {userName.title()}"
#            bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
#            bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
#            bb += "\n⇒Note: Failed Login Sb"
#            bb += f"\n\n® {settings['team']}"
#            arif.sendTag(to, bb ,[login.profile.mid])
#    else:
#        try:
#            cl = LINE(userJson['authToken'],appType=userJson['appType'])
#            if checkScreen(userName) == True:
#                os.system('screen -R {} -X quit'.format(str(userName)))
#                os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
#            else:
#                os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
#            time.sleep(3)
#            if checkScreen(userName):
#                bb = "【 LOGIN 】"
#                bb += "\nType: Selfbot"
#                bb += "\n⇒User: @!"
#                bb += f"\n⇒Name: {userName.title()}"
#                bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
#                bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
#                bb += "\n⇒Note: Success Login Sb"
#                bb += f"\n\n® {settings['team']}"
#                arif.sendTag(to, bb ,[cl.profile.mid])
#            else:
#                bb = "【 LOGIN 】"
#                bb += "\nType: Selfbot"
#                bb += "\n⇒User: @!"
#                bb += f"\n⇒Name: {userName.title()}"
#                bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
#                bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
#                bb += "\n⇒Note: Failed Login Sb"
#                bb += f"\n\n® {settings['team']}"
#                arif.sendTag(to, bb ,[cl.profile.mid])
#        except Exception as e:
#            logError(e)
#            dd = "【 LOGIN 】"
#            dd += "\nType: Selfbot"
#            dd += "\n⇒User: @!"
#            dd += f"\n⇒Name: {userName.title()}"
#            dd += f"\n⇒Header: {nheader}"
#            dd += "\n⇒Note: Check My Pc"
#            dd += f"\n\n® {settings['team']}"
#            arif.sendTag(to, dd,[sender])
#            if userJson['cert'] == "":
#                r = requests.get("https://api.chstore.me/v1/lineqr",params=params)
#                qr = r.json()
#                aa = "【 LOGIN 】"
#                aa += "\nType: Selfbot"
#                aa += "\n⇒User: @!"
#                aa += f"\n⇒Name: {userName.title()}"
#                aa += f"\n⇒Header: {nheader}"
#                aa += f"\n⇒IP: {qr['result']['ip']}"
#                aa += "\n⇒Note: Type This Link"
#                aa += f"\n\n® {settings['team']}"
#                arif.sendTag(sender,  aa ,[sender])
#                arif.sendMessage(sender, f"{qr['result']['qrlink']}")
#                arif.sendImageWithURL(sender,str(qr["result"]["qrcode"]))
#                pincode = apiBE.lineGetQrPincode(qr["result"]["session"])
#                arif.sendTag(to,f"Your Pin: {pincode['result']['pincode']} @!",[sender])
#                arif.sendTag(sender,f"Your Pin: {pincode['result']['pincode']} @!",[sender])   
#                auth = apiBE.lineGetQrAuth(qr["result"]["session"])
#                token = auth["result"]["accessToken"]
#                cert = auth["result"]["certificate"]
#                login = LINE(token,appType=userJson['appType'])
#                arif.sendTag(to,"Please Wait For Login @!",[login.profile.mid])
#                userJson['authToken'] = token
#                userJson['cert'] = cert
#                time.sleep(0.5)
#                if checkScreen(userName) == True:
#                    os.system('screen -R {} -X quit'.format(str(userName)))
#                    os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
#                else:
#                    os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
#                time.sleep(3)
#                if checkScreen(userName):
#                    bb = "【 LOGIN 】"
#                    bb += "\nType: Selfbot"
#                    bb += "\n⇒User: @!"
#                    bb += f"\n⇒Name: {userName.title()}"
#                    bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
#                    bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
#                    bb += "\n⇒Note: Success Login Sb"
#                    bb += f"\n\n® {settings['team']}"
#                    arif.sendTag(to, bb ,[login.profile.mid])
#                else:
#                    bb = "【 LOGIN 】"
#                    bb += "\nType: Selfbot"
#                    bb += "\n⇒User: @!"
#                    bb += f"\n⇒Name: {userName.title()}"
#                    bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
#                    bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
#                    bb += "\n⇒Note: Failed Login Sb"
#                    bb += f"\n\n® {settings['team']}"
#                    arif.sendTag(to, bb ,[login.profile.mid])
#            else:
#                params["cert"] = userJson["cert"]
#                r = requests.get("https://api.chstore.me/v1/lineqr",params=params)
#                qr = r.json()
#                aa = "【 LOGIN 】"
#                aa += "\nType: Selfbot"
#                aa += "\n⇒User: @!"
#                aa += f"\n⇒Name: {userName.title()}"
#                aa += f"\n⇒Header: {nheader}"
#                aa += "\n⇒Note: Type This Link"
#                aa += f"\n\n® {settings['team']}"
#                arif.sendTag(sender,  aa ,[sender])
#                arif.sendMessage(sender, f"{qr['result']['qrlink']}")
#                arif.sendImageWithURL(sender,str(qr["result"]["qrcode"]))
#
#                auth = json.loads(requests.get(f"https://api.chstore.me/v1/lineqr/auth/{qr['result']['session']}",params=params).text)
#                token = auth["result"]["accessToken"]
#                cert = auth["result"]["certificate"]
#                login = LINE(token,appType=userJson['appType'])
#                arif.sendTag(to,"Please Wait For Login @!",[login.profile.mid])
#                userJson['authToken'] = token
#                userJson['cert'] = cert
#                time.sleep(0.5)
#                if checkScreen(userName) == True:
#                    os.system('screen -R {} -X quit'.format(str(userName)))
#                    os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
#                else:
#                    os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
#                time.sleep(3)
#                if checkScreen(userName):
#                    bb = "【 LOGIN 】"
#                    bb += "\nType: Selfbot"
#                    bb += "\n⇒User: @!"
#                    bb += f"\n⇒Name: {userName.title()}"
#                    bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
#                    bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
#                    bb += "\n⇒Note: Success Login Sb"
#                    bb += f"\n\n® {settings['team']}"
#                    arif.sendTag(to, bb ,[sender])
#                else:
#                    bb = "【 LOGIN 】"
#                    bb += "\nType: Selfbot"
#                    bb += "\n⇒User: @!"
#                    bb += f"\n⇒Name: {userName.title()}"
#                    bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
#                    bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
#                    bb += "\n⇒Note: Failed Login Sb"
#                    bb += f"\n\n® {settings['team']}"
#                    arif.sendTag(to, bb ,[sender])
def loginselfbot(msg,to,sender,userName,userJson,app):
    if userName not in os.listdir('user'):os.system("mkdir user/{}".format(userName))
    random.seed = (os.urandom(1024))
    randomName = ''.join(random.choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") for i in range(6))
    win = (f'DESKTOPWIN\t6.2.0\t{randomName}10\t10;SECONDARY',f'DESKTOPWIN\t7.3.0\t{randomName}10\t10;SECONDARY',f'DESKTOPWIN\t7.2.0\t{randomName}10\t10;SECONDARY',f'DESKTOPWIN\t6.3.2\t{randomName}9\t10;SECONDARY',f'DESKTOPWIN\t6.5.4\t{randomName}8\t10;SECONDARY',f'DESKTOPWIN\t6.6.0\t{randomName}7\t10;SECONDARY',f'DESKTOPWIN\t6.7.0\t{randomName}6\t10;SECONDARY',f'DESKTOPWIN\t6.7.2\t{randomName}5\t10;SECONDARY')
    desktopwin = random.choice(win)
    if app.lower() == "chrome":
        appName = "CHROMEOS\t2.4.3\tChrome OS\t1;SECONDARY"
        nheader = "CHROMEOS"
    if app.lower() == "win":
        appName = desktopwin
        nheader = "DESKTOPWIN"
    if app.lower() == "mac":
        appName = "DESKTOPMAC\t6.7.2\tMAC\t10;SECONDARY"
        nheader = "DESKTOPMAC"
    userJson['appType']  = appName
    xxxx = "https://api.imjustgood.com/lineqr"
    params = {
        "appname": appName
    }
    if userJson['authToken'] == '' and userJson["cert"] == "":
        userJson['json'] = {
            "setting": "user/{}/setting.json".format(userName),
            "listset": "user/{}/listset.json".format(userName),
            'position':'user/{}/position.json'.format(userName)
        }
        r = requests.get("https://api.chstore.me/lineqr",params=params)
        xmen = r.json()
        linkqr  = xmen["result"]["qrlink"]
        bcode = xmen["result"]["qrcode"]
        dd = "【 LOGIN 】"
        dd += "\nType: Selfbot"
        dd += "\n⇒User: @!"
        dd += f"\n⇒Name: {userName.title()}"
        dd += f"\n⇒Header: {nheader}"
        dd += f"\n\n® {settings['team']}"
        arif.sendTag(to,  dd ,[sender])
        aa = "【 LOGIN 】"
        aa += "\nType: Selfbot"
        aa += "\n⇒User: @!"
        aa += f"\n⇒Name: {userName.title()}"
        aa += f"\n⇒Header: {nheader}"
        aa += f"\n⇒IP: {linkqr}"
        aa += "\n⇒Note: Type This Link"
        aa += f"\n\n® {settings['team']}"
        loginFlex(to,sender,userName,to)
        arif.sendImageWithURL(to,bcode)
        cback = xmen["result"]["session"]
        r2 = requests.get("https://api.chstore.me/lineqr/pincode?session="+cback)
        code = json.loads(r2.text)
        pincode = code["result"]
        arif.sendTag(to,f"Your Pin: {pincode} @!",[sender])
        arif.sendTag(sender,f"Your Pin: {pincode} @!",[sender])
        r3 = requests.get("https://api.chstore.me/lineqr/auth?session="+cback)
        tokeeen = json.loads(r3.text)
        xcerts = tokeeen["result"]["certificate"]
        xauths = tokeeen["result"]["accessToken"]
        userJson['authToken'] = xauths
        userJson['cert'] = xcerts
        login = LINE(xauths,appType=userJson['appType'])
        arif.sendTag(to,"Please Wait For Login @!",[login.profile.mid])
        userJson['authToken'] = xauths
        userJson['cert'] = xcerts
        time.sleep(0.5)
        if checkScreen(userName) == True:
            os.system('screen -R {} -X quit'.format(str(userName)))
            os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
        else:
            os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
        time.sleep(3)
        if checkScreen(userName):
            bb = "【 LOGIN 】"
            bb += "\nType: Selfbot"
            bb += "\n⇒User: @!"
            bb += f"\n⇒Name: {userName.title()}"
            bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
            bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
            bb += "\n⇒Note: Success Login Sb"
            bb += f"\n\n® {settings['team']}"
            arif.sendTag(to, bb ,[login.profile.mid])
        else:
            bb = "【 LOGIN 】"
            bb += "\nType: Selfbot"
            bb += "\n⇒User: @!"
            bb += f"\n⇒Name: {userName.title()}"
            bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
            bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
            bb += "\n⇒Note: Failed Login Sb"
            bb += f"\n\n® {settings['team']}"
            arif.sendTag(to, bb ,[login.profile.mid])
    else:
        try:
            cl = LINE(userJson['authToken'],appType=userJson['appType'])
            if checkScreen(userName) == True:
                os.system('screen -R {} -X quit'.format(str(userName)))
                os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
            else:
                os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
            time.sleep(3)
            if checkScreen(userName):
                bb = "【 LOGIN 】"
                bb += "\nType: Selfbot"
                bb += "\n⇒User: @!"
                bb += f"\n⇒Name: {userName.title()}"
                bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
                bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
                bb += "\n⇒Note: Success Login Sb"
                bb += f"\n\n® {settings['team']}"
                arif.sendTag(to, bb ,[cl.profile.mid])
            else:
                bb = "【 LOGIN 】"
                bb += "\nType: Selfbot"
                bb += "\n⇒User: @!"
                bb += f"\n⇒Name: {userName.title()}"
                bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
                bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
                bb += "\n⇒Note: Failed Login Sb"
                bb += f"\n\n® {settings['team']}"
                arif.sendTag(to, bb ,[cl.profile.mid])
        except Exception as e:
            logError(e)
            dd = "【 LOGIN 】"
            dd += "\nType: Selfbot"
            dd += "\n⇒User: @!"
            dd += f"\n⇒Name: {userName.title()}"
            dd += f"\n⇒Header: {nheader}"
            dd += f"\n\n® {settings['team']}"
            arif.sendTag(to, dd,[sender])
            if userJson['cert'] == "":
                r = requests.get("https://api.chstore.me/lineqr",params=params)
                xmen = r.json()
                linkqr  = xmen["result"]["qrlink"]
                bcode = xmen["result"]["qrcode"]
                dd = "【 LOGIN 】"
                dd += "\nType: Selfbot"
                dd += "\n⇒User: @!"
                dd += f"\n⇒Name: {userName.title()}"
                dd += f"\n⇒Header: {nheader}"
                dd += f"\n\n® {settings['team']}"
                arif.sendTag(to,  dd ,[sender])
                aa = "【 LOGIN 】"
                aa += "\nType: Selfbot"
                aa += "\n⇒User: @!"
                aa += f"\n⇒Name: {userName.title()}"
                aa += f"\n⇒Header: {nheader}"
                aa += f"\n⇒IP: {linkqr}"
                aa += "\n⇒Note: Type This Link"
                aa += f"\n\n® {settings['team']}"
                loginFlex(to,sender,userName,to)
                arif.sendImageWithURL(to,bcode)
                cback = xmen["result"]["session"]
                r2 = requests.get("https://api.chstore.me/lineqr/pincode?session="+cback)
                code = json.loads(r2.text)
                pincode = code["result"]
                arif.sendTag(to,f"Your Pin: {pincode} @!",[sender])
                arif.sendTag(sender,f"Your Pin: {pincode} @!",[sender])
                r3 = requests.get("https://api.chstore.me/lineqr/auth?session="+cback)
                tokeeen = json.loads(r3.text)
                xcerts = tokeeen["result"]["certificate"]
                xauths = tokeeen["result"]["accessToken"]
                userJson['authToken'] = xauths
                userJson['cert'] = xcerts
                login = LINE(xauths,appType=userJson['appType'])
                arif.sendTag(to,"Please Wait For Login @!",[login.profile.mid])
                userJson['authToken'] = xauths
                userJson['cert'] = xcerts
                time.sleep(0.5)
                if checkScreen(userName) == True:
                    os.system('screen -R {} -X quit'.format(str(userName)))
                    os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
                else:
                    os.system('screen -S {} -dm python3 main.py -u {}'.format(userName,userName))
                time.sleep(3)
                if checkScreen(userName):
                    bb = "【 LOGIN 】"
                    bb += "\nType: Selfbot"
                    bb += "\n⇒User: @!"
                    bb += f"\n⇒Name: {userName.title()}"
                    bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
                    bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
                    bb += "\n⇒Note: Success Login Sb"
                    bb += f"\n\n® {settings['team']}"
                    arif.sendTag(to, bb ,[login.profile.mid])
                else:
                    bb = "【 LOGIN 】"
                    bb += "\nType: Selfbot"
                    bb += "\n⇒User: @!"
                    bb += f"\n⇒Name: {userName.title()}"
                    bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
                    bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
                    bb += "\n⇒Note: Failed Login Sb"
                    bb += f"\n\n® {settings['team']}"
                    arif.sendTag(to, bb ,[login.profile.mid])
            else:
                r = requests.get("https://api.chstore.me/lineqr",params=params)
                xmen = r.json()
                linkqr  = xmen["result"]["qrlink"]
                bcode = xmen["result"]["qrcode"]
                dd = "【 LOGIN 】"
                dd += "\nType: Selfbot"
                dd += "\n⇒User: @!"
                dd += f"\n⇒Name: {userName.title()}"
                dd += f"\n⇒Header: {nheader}"
                dd += f"\n\n® {settings['team']}"
                arif.sendTag(to,  dd ,[sender])
                aa = "【 LOGIN 】"
                aa += "\nType: Selfbot"
                aa += "\n⇒User: @!"
                aa += f"\n⇒Name: {userName.title()}"
                aa += f"\n⇒Header: {nheader}"
                aa += f"\n⇒IP: {linkqr}"
                aa += "\n⇒Note: Type This Link"
                aa += f"\n\n® {settings['team']}"
                loginFlex(to,sender,userName,to)
                arif.sendImageWithURL(to,bcode)
                cback = xmen["result"]["session"]
                r2 = requests.get("https://api.chstore.me/lineqr/pincode?session="+cback)
                code = json.loads(r2.text)
                pincode = code["result"]
                arif.sendTag(to,f"Your Pin: {pincode} @!",[sender])
                arif.sendTag(sender,f"Your Pin: {pincode} @!",[sender])
                r3 = requests.get("https://api.chstore.me/lineqr/auth?session="+cback)
                tokeeen = json.loads(r3.text)
                xcerts = tokeeen["result"]["certificate"]
                xauths = tokeeen["result"]["accessToken"]
                userJson['authToken'] = xauths
                userJson['cert'] = xcerts
                login = LINE(xauths,appType=userJson['appType'])
                arif.sendTag(to,"Please Wait For Login @!",[login.profile.mid])
                userJson['authToken'] = xauths
                userJson['cert'] = xcerts
                time.sleep(0.5)
                if checkScreen(userName) == True:
                    os.system('screen -R {} -X quit'.format(str(userName)))
                    os.system('screen -S {} -dm python3 arif.py -u {}'.format(userName,userName))
                else:
                    os.system('screen -S {} -dm python3 arif.py -u {}'.format(userName,userName))
                time.sleep(3)
                if checkScreen(userName):
                    bb = "【 LOGIN 】"
                    bb += "\nType: Selfbot"
                    bb += "\n⇒User: @!"
                    bb += f"\n⇒Name: {userName.title()}"
                    bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
                    bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
                    bb += "\n⇒Note: Success Login Sb"
                    bb += f"\n\n® {settings['team']}"
                    arif.sendTag(to, bb ,[sender])
                else:
                    bb = "【 LOGIN 】"
                    bb += "\nType: Selfbot"
                    bb += "\n⇒User: @!"
                    bb += f"\n⇒Name: {userName.title()}"
                    bb += f"\n⇒Date: {parser.parse(userJson['expired']).strftime('%d-%m-%Y')}"
                    bb += f"\n⇒Time: {parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')}"
                    bb += "\n⇒Note: Failed Login Sb"
                    bb += f"\n\n® {settings['team']}"
                    arif.sendTag(to, bb ,[sender])

def changevideopp(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = arif.genOBSParams({'oid': myMid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'Hello_World.mp4'})
        data = {'params': obs_params}
        r_vp = arif.server.postContent('{}/talk/vp/upload.nhn'.format(str(arif.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        arif.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:raise Exception("Error change video and picture profile %s"%str(e))

def qrOpen(blek):
    group = arif.getChats([blek], True , False).chats[0];group.extra.groupExtra.preventedJoinByTicket = False;arif.updateChat(group , 4);gurl = arif.reissueChatTicket(blek)
    return gurl.ticketId

def qrClose(blek):
    group = arif.getChats([blek], True , False).chats[0];group.extra.groupExtra.preventedJoinByTicket = True;arif.updateChat(group , 4)

def notified_invited(op):
    if myMid in op.param3:
        if op.param2 in bos or op.param2 in own or op.param2 in usr:
            accepted(op.param1)

def notified_add(op):
    arif.sendMessage(op.param1,"Thank You For Addme, This Helper Selbot v5")
    arif.sendContact(op.param1, 'u6459106c8251205f79c2f037cd99b6a4')
    finded(op.param1)

def notified_operation(op):
    msg      = op.message
    text     = str(msg.text)
    msg_id   = msg.id
    receiver = msg.to
    sender   = msg._from
    to       = sender if not msg.toType and sender != myMid else receiver
    txt      = text.lower()
    cmd      = command(text)
    setKey   = settings['setKey']['key'] if settings['setKey']['status'] else ''
    if msg.contentType == 0:
        try:
            executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey)                   
        except TalkException as talk_error:
            logError(talk_error)
            if talk_error.code in [7, 8, 20]:
                sys.exit(1)                       
            print(str(talk_error))
            time.sleep(3)
        except Exception as error:
            logError(error)
            print(str(error))
            time.sleep(3)

#====================𝙎𝙏𝘼𝙍𝙏=======================
def executeCmd(msg, text, txt, cmd,msg_id, receiver, sender, to, setKey):
    for cmd in cmd.split(" & "):
        if cmd == 'mute' or commandMen(msg, text, 'mute'):
          if msg._from in bos or msg._from in own:
            if to in settings['silent']:
                arif.sendMessage(to,"Already♪")           
            else:
                settings['silent'].append(to)
                arif.sendMessage(to,"Succes♪") 
                     
        elif cmd == 'unmute' or commandMen(msg, text, 'unmute'):
          if msg._from in bos or msg._from in own:
            if to not in settings['silent']:
                arif.sendMessage(to,"Already♪")           
            else:
                settings['silent'].remove(to)
                arif.sendMessage(to,"Succes♪")                       
        if to in settings['silent']:
            return

        if cmd == 'restart' or commandMen(msg, text, 'restart'):
            if msg._from in bos or msg._from in own:  
                arif.sendMessage(to,"Wait♪")
                settings['restartPoint'] = to
                restartProgram()

        elif cmd.startswith("exec") or commandMen(msg, text, 'exec'):
            if msg._from in bos:
                try:
                    sep = text.split("\n")
                    txt = text.replace(sep[0] + "\n","")
                    exec(txt)
                except Exception as e:
                    arif.sendMessage(to, str(e))

        elif cmd == 'error logs':
            if msg._from in bos: 
                try:
                    filee = open('errorLog.txt', 'r')
                except FileNotFoundError:
                    arif.sendMessage(to,"Nothing♪")
                errors = [err.strip() for err in filee.readlines()]
                filee.close()
                if not errors: arif.sendMessage(to,"Nothing♪")
                res = ' 【 HELP 】 '
                res += '\nType: Logs'
                parsed_len = len(errors)//200+1
                no = 0
                for point in range(parsed_len):
                    for error in errors[point*200:(point+1)*200]:
                        if not error: continue
                        no += 1
                        res += '\n⇒%i. %s' % (no, error)
                        if error == errors[-1]:
                            res += ''
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        arif.sendMessage(to, res)
                    res = '' 

        elif cmd == 'error reset':
            if msg._from in bos: 
                filee = open('errorLog.txt', 'w')
                filee.write('')
                filee.close()
                shutil.rmtree('tmp/errors/', ignore_errors=True)
                os.system('mkdir tmp/errors')
                arif.sendMessage(to,"Done♪")

        elif cmd.startswith("error detail"):
            if msg._from in bos:
                ktl = text.split('detail ')
                errid = text.replace(ktl[0] + 'detail ','')
                if os.path.exists('tmp/errors/%s.txt' % errid):
                    with open('tmp/errors/%s.txt' % errid, 'r') as f:
                        arif.sendMessage(to, f.read())
                else:
                    arif.sendMessage(to,"Failed♪")

#====================𝙃𝙀𝙇𝙋======="================
        elif cmd == 'help' or commandMen(msg, text, 'help'):
            if msg._from in bos or msg._from in own or msg._from in usr:
                bb = "【 HELP 】"
                bb += "\nType: Helper"
                bb += "\nCommand User:"
                bb += "\n⇒ Key"
                bb += f"\n⇒{setKey.title()} About"
                bb += f"\n⇒{setKey.title()} Login"
                bb += f"\n⇒{setKey.title()} Expired"
                bb += f"\n⇒{setKey.title()} Speed"
                bb += f"\n⇒{setKey.title()} Cvprim"
                bb += "\n\nCommand Owner:"
                bb += "\n⇒ Ping"
                bb += f"\n⇒{setKey.title()} Menu"
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif cmd == 'cvprim':
            if msg._from in bos or msg._from in own or msg._from in usr:
                bb = "【 CONVERT 】"
                bb += "\nType: Primary"
                bb += "\nList App:"                
                bb += "\n⇒1 : Mac"
                bb += "\n⇒2 : Win"
                bb += "\n⇒3 : Chrome"
                bb += "\n\nCommand:"      
                bb += f"\n⇒{setKey.title()} Cvprim ‹A› ‹T›"
                bb += "\n\nTrigger:"      
                bb += f"\n⇒A: App"
                bb += f"\n⇒T: Token"
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)


        elif cmd.startswith("cvprim mac"):
            if msg._from in bos or msg._from in own or msg._from in usr:
                ktl = text.split('mac ')
                mmk = text.replace(ktl[0] + 'mac ','') 
                arif.sendTag(to,"Please Check My Pc For Token @!",[sender])
                try:    
                    params = {
                        "authtoken": mmk,
                        "apptype": "DESKTOPMAC"
                    }
                    r = requests.get("https://minz-restapi.xyz/authtosecondary",params=params)
                    convert = r.json()
                    arif.sendMessage(sender, convert["result"]["accessToken"])
                    arif.sendMessage(to,"Done♪")
                except Exception as error:
                    arif.sendMessage(sender, "YOU TOKEN BANNED")
                    arif.sendTag(to, "YOU TOKEN BANNED @!",[sender])

        elif cmd.startswith("cvprim win"):
            if msg._from in bos or msg._from in own or msg._from in usr:
                ktl = text.split('win ')
                mmk = text.replace(ktl[0] + 'win ','') 
                arif.sendTag(to,"Please Check My Pc For Token @!",[sender])
                try:                             
                    params = {
                        "authtoken": mmk,
                        "apptype": "DESKTOPWIN"
                    }
                    r = requests.get("https://minz-restapi.xyz/authtosecondary",params=params)
                    convert = r.json()
                    arif.sendMessage(sender, convert["result"]["accessToken"])
                    arif.sendMessage(to,"Done♪")
                except Exception as error:
                    arif.sendMessage(sender, "YOU TOKEN BANNED")
                    arif.sendTag(to, "YOU TOKEN BANNED @!",[sender])

        elif cmd.startswith("cvprim chrome"):
            if msg._from in bos or msg._from in own or msg._from in usr:
                ktl = text.split('chrome ')
                mmk = text.replace(ktl[0] + 'chrome ','') 
                arif.sendTag(to,"Please Check My Pc For Token @!",[sender])
                try:       
                    params = {
                        "authtoken": mmk,
                        "apptype": "CHROMEOS"
                    }
                    r = requests.get("https://minz-restapi.xyz/authtosecondary",params=params)
                    convert = r.json()
                    arif.sendMessage(sender, convert["result"]["accessToken"])
                    arif.sendMessage(to,"Done♪")
                except Exception as error:
                    arif.sendMessage(sender, "YOU TOKEN BANNED")
                    arif.sendTag(to, "YOU TOKEN BANNED @!",[sender])



        elif txt == 'key':
            if msg._from in bos or msg._from in own or msg._from in usr:
                bb = "【 KEY 】"
                bb += "\nType: Helper"
                bb += "\nCondition:"
                bb += f"\n⇒Rname: {setKey.title()}"
                bb += f"\n⇒Status: {bool_dict[settings['setKey']['status']][1]}"
                arif.sendMessage(to, bb)

        elif cmd == 'about':
            if msg._from in bos or msg._from in own or msg._from in usr:
                mids = []
                jmlhsb = []
                usermid = [a for a in defaultJson['role']['user']]
                for x in usermid:
                    jmlhsb.append(x)
                rahmanirza = ["u6459106c8251205f79c2f037cd99b6a4"]
                for irzarahman in rahmanirza:
                    mids.append(irzarahman)
                kalera = ["u6459106c8251205f79c2f037cd99b6a4"]
                for red in kalera:
                    mids.append(red)
                sangeee = arif.getSettings().e2eeEnable
                if sangeee == True:
                    letsel = "Lettersealing: ✓"
                if sangeee == False:
                    letsel = "Lettersealing: ✘"
                bb = "【 ABOUT 】"
                bb += "\nType: Helper"
                bb += "\n⇒Version: 2.0"
                bb += "\n⇒Rework: @!"
                bb += "\n⇒Store: @!"
                bb += "\n⇒Libary: Linepy"
                bb += f"\n⇒User Sb: {len(jmlhsb)}"
                bb += "\n\nSpecial Thanks To:"
                bb += "\n⇒Alm. Zero Cool"
                bb += "\n⇒Talk Exception"
                bb += "\n⇒Aldita"
                arif.sendTag(to, bb , mids)

        elif cmd == 'login' or commandMen(msg, text, 'mute'):
            if msg._from in bos or msg._from in own or msg._from in usr:
                bb = "【 LOGIN 】"
                bb += "\nType: Helper"
                bb += "\nList App:"                
                bb += "\n⇒1 : Mac"
                bb += "\n⇒2 : Win"
                bb += "\n⇒3 : Chrome"
                bb += "\n\nLogin Sb:"      
                bb += f"\n⇒{setKey.title()} Loginsb ‹App› "
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif cmd == 'expired' or commandMen(msg, text, 'expired'):
            if msg._from in bos or msg._from in own or msg._from in usr:
                userName = defaultJson['role']['user'][msg._from]
                userJson = defaultJson['role']['info'][userName]
                date = parser.parse(userJson['expired']).strftime('%d-%m-%Y')
                timex = parser.parse(userJson['expired']).strftime('%H:%M:%S WIB')
                bb = "【 EXPIRED 】"
                bb += "\nType: Helper"
                bb += f"\n⇒Name: {userName.title()}"
                bb += f"\n⇒Date: {date}"
                bb += f"\n⇒Time: {timex}"
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif cmd == 'speed' or commandMen(msg, text, 'speed'):
            if msg._from in bos or msg._from in own or msg._from in usr:          
                a = time.time()
                b = arif.getProfile()
                c = time.time() - a
                d = time.time() - a
                arif.sendMessage(to, "%s ms♪" % (round(c * 1000,2)))
               
        elif txt == 'backupfile':
            if msg._from in bos or msg._from in own:    
                arif.sendTag(to, "My Bous @! Waiting For Backup File!!!", [sender])
                os.system("apt install zip -y")
                os.system("zip -r MORIS.zip cd /root/moris")
                fox = "MORIS.zip"
                arif.sendFile(msg._from,fox)
                arif.sendTag(to, "Success @!\nDone Send File In Your Chat!!!", [sender])
                
        elif txt == 'ping':
            if msg._from in bos or msg._from in own:          
                arif.sendTag(to, "PONG !!! @!", [sender])

        elif cmd == 'menu' or commandMen(msg, text, 'menu'):
            if msg._from in bos or msg._from in own:
                bb = "【 MENU 】"
                bb += "\nType: Helper"             
                bb += f"\n⇒{setKey.title()} Grade "
                bb += f"\n⇒{setKey.title()} User "
                bb += f"\n⇒{setKey.title()} Profile "
                bb += f"\n⇒{setKey.title()} Group "
                bb += "\n\nCommand Creator:" 
                bb += f"\n⇒{setKey.title()} File "
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif txt.startswith("key") or commandMen(msg, text, 'key'):
            if msg._from in bos or msg._from in own:
                ktl = text.split('y ')
                mmk = text.replace(ktl[0] + 'y ','')        
                if mmk == 'on':
                    if settings['setKey']['status']:
                        arif.sendMessage(to, 'Already♪')               
                    else:
                        settings['setKey']['status'] = True
                        arif.sendMessage(to, 'Active♪')                               
                elif mmk == 'off':
                    if not settings['setKey']['status']:
                        arif.sendMessage(to, 'Already♪')            
                    else:
                        settings['setKey']['status'] = False
                        arif.sendMessage(to, 'Deactive♪')          
                else:
                    settings['setKey']['key'] = mmk
                    arif.sendMessage(to, 'Done♪')               
   
        elif cmd.startswith("loginsb"):
            if  msg._from in usr:          
                sep = cmd.replace(cmd.split(" ")[0]+" ","")
                userName = defaultJson['role']['user'][msg._from]
                userJson = defaultJson['role']['info'][userName]
                if sep.split(" ")[0].lower() == "mac" or sep.split(" ")[0].lower() == "1":
                    loginselfbot(msg, to, msg._from, userName, userJson,"mac")
                if sep.split(" ")[0].lower() == "win" or sep.split(" ")[0].lower() == "2":
                    loginselfbot(msg, to, msg._from, userName, userJson, "win")
                if sep.split(" ")[0].lower() == "chrome" or sep.split(" ")[0].lower() == "3":
                    loginselfbot(msg, to, msg._from, userName, userJson, "chrome")

       
        elif cmd == 'grade' or commandMen(msg, text, 'grade'):
            if msg._from in bos or msg._from in own:
                mids = eval(str(settings["thebos"])) + eval(str(settings["owner"]))
                result = '【 GRADE 】'
                result += '\nType: List'
                no = 0
                for i in range(len(mids)//20+1):
                    target = []
                    for mid in mids[i*20:(i+1)*20]:
                        no += 1
                        if settings["thebos"] and mid == settings["thebos"][0]:
                            result += '\nBos:\n'
                        if settings["owner"] and mid == settings["owner"][0]:
                            no = 1
                            result += '\nOwner:\n'
                        result += f'⇒{no}. @!\n'
                        if mid == mids[-1]:
                            result += '\n\nCommand:'
                            result += f'\n⇒{setKey.title()} Owner Add ‹*›'
                            result += f'\n⇒{setKey.title()} Owner Del ‹**›'
                            result += f'\n⇒{setKey.title()} Owner Clear'
                            result += '\n\nTrigger:'
                            result += '\n⇒* = ‹@/Reply›'
                            result += '\n⇒** = ‹@/Reply/Num›'
                            result += f"\n\n® {settings['team']}"
                        target.append(mid)
                    if result.startswith('\n'): result = result[1:]
                    if result.endswith('\n'): result = result[:-1]
                    arif.sendTag(to, result, target)
                    result = ''

        elif cmd.startswith("owner add"):
            if msg._from in bos:
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    arif.datamentionss(to,'GRADE',list,'ADDOWNER',settings,ps='\nType: Owner')
                else:
                    bb = geTreply(msg)
                    if bb._from not in settings["owner"] and bb._from not in settings["thebos"] and bb._from not in myMid:
                        settings["owner"].append(bb._from)
                        cc = "【 GRADE 】"
                        cc += "\nType: Owner"
                        cc += "\n⇒1. @! Add ♪"
                        arif.sendTag(to, cc,[bb._from])
                    else:
                        cc = "【 GRADE 】"
                        cc += "\nType: Owner"
                        cc += "\n⇒1. @! Already ♪"
                        arif.sendTag(to, cc,[bb._from])

        elif cmd.startswith("owner del"):
            if msg._from in bos:
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    arif.datamentionss(to,'GRADE',list,'DELOWNER',settings,ps='\nType: Owner')
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if bb._from in settings["owner"]:
                            settings["owner"].remove(bb._from)
                            cc = "【 GRADE 】"
                            cc += "\nType: Owner"
                            cc += "\n⇒1. @! Del ♪"
                            arif.sendTag(to, cc,[bb._from])
                        else:
                            cc = "【 GRADE 】"
                            cc += "\nType: Owner"
                            cc += "\n⇒1. @! Nothing ♪"
                            arif.sendTag(to, cc,[bb._from])
                    else:
                        try:
                            ktl = text.split("del ")
                            mmk = text.replace(ktl[0] + "del ","")
                            x = splitdel(str(mmk), settings["owner"])
                            z = len(settings["owner"])//100
                            for c in range(z+1):
                                if c == 0:
                                    arif.datamentionss(to,'GRADE',x[:100],'DELOWNER',settings,ps='\nType: Owner')
                                else:
                                    arif.datamentionss(to,'GRADE',x[c*100 : (c+1)*100],'DELOWNER',settings,ps='\nType: Owner')
                        except:
                            arif.sendMessage(to,"【 GRADE 】\nType: Owner\n⇒Note: Command Error")                              

        elif cmd.startswith("owner del"):
            if msg._from in bos:
                if len(settings["owner"]) > 0:
                    arif.sendMessage(to, "Done♪")
                    settings["owner"].clear()                       
                else:
                    arif.sendMessage(to, "Nothing♪")

        elif cmd == 'user':
            if msg._from in bos or msg._from in own:
                bb = "【 USER 】"
                bb += "\nType: Helper"             
                bb += f"\n⇒{setKey.title()} Addsb ‹N› ‹R/@›"
                bb += f"\n⇒{setKey.title()} Delsb ‹R/N/@›"
                bb += f"\n⇒{setKey.title()} Changesb ‹N› ‹R/@›"
                bb += f"\n⇒{setKey.title()} list user"
                bb += f"\n⇒{setKey.title()} Time User"
                bb += "\n\nCommand Owner:"
                bb += f"\n⇒{setKey.title()} Addme Sb ‹N›"   
                bb += "\n\nTrigger:"
                bb += "\n⇒A = All"
                bb += "\n⇒R = Reply"
                bb += "\n⇒@ = Tag"
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif cmd.startswith("addsb"):
            if msg._from in bos or msg._from in own:    
                ktl = text.split("sb ")
                mmk = text.replace(ktl[0] + "sb ","")
                tol = mmk.split(" ")
                name = tol[0]  
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    miduser = ""
                    for xx in list:
                        miduser = xx  
                    if miduser not in defaultJson['role']['user']:
                        defaultJson['role']['user'][miduser] = name
                        defaultJson['role']['info'][name] = {
                            'group':to,
                            'mid': miduser,
                            'authToken': '',
                            'cert':'',
                            'json': {},
                            'appType': '',
                            'expired':str(datetime.now(tz=pytz.timezone("Asia/Jakarta"))+timedelta(days=30))
                        }
                        time.sleep(0.5)
                        bb = "【 USER 】"
                        bb += "\nType: Addsb"             
                        bb += "\n⇒User: @!"
                        bb += f"\n⇒Name: {name.title()}"
                        bb += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                        bb += "\n⇒Note: New User"
                        arif.sendTag(to, bb, [miduser])
                    else:
                        xnm = defaultJson['role']['user'][miduser]
                        bb = "【 USER 】"
                        bb += "\nType: Addsb"             
                        bb += "\n⇒User: @!"
                        bb += f"\n⇒Name: {xnm.title()}"
                        bb += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][xnm]["expired"]).strftime("%d-%m-%Y")}'
                        bb += "\n⇒Note: Already"
                        arif.sendTag(to, bb, [miduser])
                else:
                    bb = geTreply(msg)
                    if bb._from not in defaultJson['role']['user']:
                        defaultJson['role']['user'][bb._from] = name
                        defaultJson['role']['info'][name] = {
                            'group':to,
                            'mid': bb._from,
                            'authToken': '',
                            'cert':'',
                            'json': {},
                            'appType': '',
                            'expired':str(datetime.now(tz=pytz.timezone("Asia/Jakarta"))+timedelta(days=30))
                        }
                        time.sleep(0.5)
                        cc = "【 USER 】"
                        cc += "\nType: Addsb"             
                        cc += "\n⇒User: @!"
                        cc += f"\n⇒Name: {name.title()}"
                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                        cc += "\n⇒Note: New User"
                        arif.sendTag(to, cc, [bb._from])
                    else:
                        xnm = defaultJson['role']['user'][bb._from]
                        cc = "【 USER 】"
                        cc += "\nType: Addsb"             
                        cc += "\n⇒User: @!"
                        cc += f"\n⇒Name: {xnm.title()}"
                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][xnm]["expired"]).strftime("%d-%m-%Y")}'
                        cc += "\n⇒Note: Already"
                        arif.sendTag(to, cc, [bb._from])

        elif cmd.startswith("delsb"):
            if msg._from in bos or msg._from in own:                 
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    for cau in list:
                        if cau in defaultJson['role']['user']:
                            namee = defaultJson['role']['user'][cau]
                            os.system("screen -R {} -X quit".format(namee))
                            del defaultJson['role']['info'][namee]
                            del defaultJson['role']['user'][cau]
                            time.sleep(0.5)
                            cc = "【 USER 】"
                            cc += "\nType: Delsb"            
                            cc += f"\n⇒User: @!"
                            cc += f"\n⇒Name: {namee.title()}"
                            cc += "\n⇒Note: Del User"
                            arif.sendTag(to, cc, [cau])
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Delsb"             
                            cc += f"\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [cau])
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if bb._from in defaultJson['role']['user']:
                            namee = defaultJson['role']['user'][bb._from]
                            os.system("screen -R {} -X quit".format(namee))
                            del defaultJson['role']['info'][namee]
                            del defaultJson['role']['user'][bb._from]
                            time.sleep(0.5)
                            cc = "【 USER 】"
                            cc += "\nType: Delsb"            
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {namee.title()}"
                            cc += "\n⇒Note: Del User"
                            arif.sendTag(to, cc, [bb._from])
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Delsb"             
                            cc += f"\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [bb._from])
                    else:
                        ktl = text.split("sb ")
                        mmk = text.replace(ktl[0] + "sb ","")  
                        for asu in mmk.split(","):
                            if asu in defaultJson['role']['info']:
                                if checkScreen(asu) == True:
                                    os.system("screen -R {} -X quit".format(asu))
                                miduser =  defaultJson['role']['info'][asu]['mid']
                                del defaultJson['role']['user'][miduser]
                                del defaultJson['role']['info'][asu]
                                time.sleep(0.5)
                                cc = "【 USER 】"
                                cc += "\nType: Delsb"            
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {asu.title()}"
                                cc += "\n⇒Note: Del User"
                                arif.sendTag(to, cc, [miduser])
                            else:
                                cc = "【 USER 】"
                                cc += "\nType: Delsb"             
                                cc += f"\n⇒Name: {asu.title()}"
                                cc += "\n⇒Note: Nothing User"
                                arif.sendMessage(to, cc)

        elif cmd.startswith("changesb"):
            if msg._from in bos or msg._from in own:    
                ktl = text.split("sb ")
                mmk = text.replace(ktl[0] + "sb ","")
                tol = mmk.split(" ")
                name = tol[0]  
                if name in defaultJson['role']['info']:
                    if checkScreen(name) == True:
                        os.system("screen -R {} -X quit".format(name))
                    miduserr =  defaultJson['role']['info'][name]['mid']
                    del defaultJson['role']['user'][miduserr]
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    miduser = ""
                    for xx in list:
                        miduser = xx 
                    defaultJson['role']['info'][name]['mid'] = miduser
                    defaultJson['role']['info'][name]['group'] = to
                    defaultJson['role']['info'][name]['authToken'] = ''
                    defaultJson['role']['info'][name]['cert'] = ''
                    defaultJson['role']['info'][name]['appType'] = ''
                    if miduser not in defaultJson['role']['user']:
                        defaultJson['role']['user'][miduser] = name
                        time.sleep(0.5)
                        bb = "【 USER 】"
                        bb += "\nType: Changesb"             
                        bb += "\n⇒User: @!"
                        bb += f"\n⇒Name: {name.title()}"
                        bb += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                        bb += "\n⇒Note: Succes Change"
                        arif.sendTag(to, bb, [miduser])
                    else:
                        xnm = defaultJson['role']['user'][miduser]
                        bb = "【 USER 】"
                        bb += "\nType: Changesb"             
                        bb += "\n⇒User: @!"
                        bb += f"\n⇒Name: {xnm.title()}"
                        bb += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][xnm]["expired"]).strftime("%d-%m-%Y")}'
                        bb += "\n⇒Note: Already"
                        arif.sendTag(to, bb, [miduser])
                else:
                    bb = geTreply(msg)
                    defaultJson['role']['info'][name]['mid'] = bb._from
                    defaultJson['role']['info'][name]['group'] = to
                    defaultJson['role']['info'][name]['authToken'] = ''
                    defaultJson['role']['info'][name]['cert'] = ''
                    defaultJson['role']['info'][name]['appType'] = ''
                    if bb._from not in defaultJson['role']['user']:
                        defaultJson['role']['user'][bb._from] = name
                        time.sleep(0.5)
                        cc = "【 USER 】"
                        cc += "\nType: Changesb"             
                        cc += "\n⇒User: @!"
                        cc += f"\n⇒Name: {name.title()}"
                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                        cc += "\n⇒Note: Succes Change"
                        arif.sendTag(to, cc, [bb._from])
                    else:
                        xnm = defaultJson['role']['user'][bb._from]
                        cc = "【 USER 】"
                        cc += "\nType: Changesb"             
                        cc += "\n⇒User: @!"
                        cc += f"\n⇒Name: {xnm.title()}"
                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][xnm]["expired"]).strftime("%d-%m-%Y")}'
                        cc += "\n⇒Note: Already"
                        arif.sendTag(to, cc, [bb._from])

        elif cmd == 'list user' or commandMen(msg, text, 'list user'):
            if msg._from in bos or msg._from in own:
                namasb = []
                usermid = [a for a in defaultJson['role']['user']]
                for x in usermid:
                    namasb.append(x)
                mids = eval(str(namasb))
                result = '【 USER 】'
                result += '\nType: Status'
                no = 0
                for i in range(len(mids)//20+1):
                    target = []
                    for mid in mids[i*20:(i+1)*20]:
                        name = defaultJson['role']['user'][mid]
                        if checkScreen(name):
                            statusnya ="✓"
                        else:
                            statusnya ="✘"
                        no += 1
                        if namasb and mid == namasb[0]:
                            result += '\nSB:\n'
                        result += f'{no}. User: @!\n'      
                        result += f'  ⇒Nama: {name.title()}\n'
                        result += f'  ⇒Status: {statusnya}\n'
                        if mid == mids[-1]:
                            result += "\n\nCommand:"
                            result += f"\n⇒{setKey.title()} Reboot  ‹N/R/@/A›"
                            result += f"\n⇒{setKey.title()} Kill ‹N/R/@/A›"
                            result += "\n\nTrigger:"
                            result += "\n⇒A = All"
                            result += "\n⇒N = Name"
                            result += "\n⇒R = Reply"
                            result += "\n⇒@ = Tag"
                            result += f"\n\n® {settings['team']}"
                        target.append(mid)
                    if result.startswith('\n'): result = result[1:]
                    if result.endswith('\n'): result = result[:-1]
                    arif.sendTag(to, result, target)
                    result = ''

        elif cmd.startswith("reboot") or commandMen(msg, text, 'reboot'):
            if msg._from in bos or msg._from in own:                
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    for x in list:
                        if x in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][x]
                            arif.sendMessage(to, "Please Wait")
                            if checkScreen(name) == True:
                                os.system('screen -R {} -X quit'.format(str(name)))
                                os.system('screen -S {} -dm python3 main.py -u {}'.format(name,name))
                            else:
                                os.system('screen -S {} -dm python3 main.py -u {}'.format(name,name))
                            time.sleep(2)
                            if checkScreen(name) == True:
                                cc = "【 USER 】"
                                cc += "\nType: Reboot"             
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {name.title()}"
                                cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                cc += "\n⇒Note: Success Reboot"
                                arif.sendTag(to, cc, [x])
                            else:
                                cc = "【 USER 】"
                                cc += "\nType: Reboot"             
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {name.title()}"
                                cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                cc += "\n⇒Note: Failed Reboot"
                                arif.sendTag(to, cc, [x])
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Reboot"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [x]) 
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if bb._from in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][bb._from]
                            arif.sendMessage(to, "Please Wait")
                            if checkScreen(name) == True:
                                os.system('screen -R {} -X quit'.format(str(name)))
                                os.system('screen -S {} -dm python3 main.py -u {}'.format(name,name))
                            else:
                                os.system('screen -S {} -dm python3 main.py -u {}'.format(name,name))
                            time.sleep(2)
                            if checkScreen(name) == True:
                                cc = "【 USER 】"
                                cc += "\nType: Reboot"             
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {name.title()}"
                                cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                cc += "\n⇒Note: Success Reboot"
                                arif.sendTag(to, cc, [bb._from])
                            else:
                                cc = "【 USER 】"
                                cc += "\nType: Reboot"             
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {name.title()}"
                                cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                cc += "\n⇒Note: Failed Reboot"
                                arif.sendTag(to, cc, [bb._from])
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Reboot"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [bb._from]) 
                    else:
                        ktl = cmd.split(" ")
                        mmk = cmd.replace(ktl[0] + " ","") 
                        tol = mmk.split(" ")
                        target = tol[0]
                        if target == "all":
                            usermid = [i for i in defaultJson['role']['user']]
                            arif.sendMessage(to, "Please Wait")
                            for xx in usermid:
                                name = defaultJson['role']['user'][xx]
                                if checkScreen(name) == True:
                                    os.system('screen -R {} -X quit'.format(str(name)))
                                    os.system('screen -S {} -dm python3 main.py -u {}'.format(name,name))
                                else:
                                    os.system('screen -S {} -dm python3 main.py -u {}'.format(name,name))
                                time.sleep(2)
                            cc = "【 USER 】"
                            cc += "\nType: Addday"             
                            cc += "\n⇒User: All"
                            cc += "\n⇒Note: Success Reboot"
                            arif.sendMessage(to, cc)
                        else:
                            for xxx in target.split(","):
                                miduser =  defaultJson['role']['info'][xxx]['mid']
                                if miduser in defaultJson['role']['user']:
                                    name = defaultJson['role']['user'][miduser]
                                    arif.sendMessage(to, "Please Wait")
                                    if checkScreen(name) == True:
                                        os.system('screen -R {} -X quit'.format(str(name)))
                                        os.system('screen -S {} -dm python3 main.py -u {}'.format(name,name))
                                    else:
                                        os.system('screen -S {} -dm python3 main.py -u {}'.format(name,name))
                                    time.sleep(2)
                                    if checkScreen(name) == True:
                                        cc = "【 USER 】"
                                        cc += "\nType: Reboot"             
                                        cc += "\n⇒User: @!"
                                        cc += f"\n⇒Name: {name.title()}"
                                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                        cc += "\n⇒Note: Success Reboot"
                                        arif.sendTag(to, cc, [miduser])
                                    else:
                                        cc = "【 USER 】"
                                        cc += "\nType: Reboot"             
                                        cc += "\n⇒User: @!"
                                        cc += f"\n⇒Name: {name.title()}"
                                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                        cc += "\n⇒Note: Failed Reboot"
                                        arif.sendTag(to, cc, [miduser])
                                else:
                                    cc = "【 USER 】"
                                    cc += "\nType: Reboot"             
                                    cc += "\n⇒Name: {xxx.title()}"
                                    cc += "\n⇒Note: Nothing User"
                                    arif.sendMessage(to, cc)

        elif cmd.startswith("kill") or commandMen(msg, text, 'kill'):
            if msg._from in bos or msg._from in own:                
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    for x in list:
                        if x in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][x]
                            arif.sendMessage(to, "Please Wait")
                            if checkScreen(name) == True:
                                os.system('screen -R {} -X quit'.format(str(name)))
                            time.sleep(2)
                            if checkScreen(name) == True:
                                cc = "【 USER 】"
                                cc += "\nType: Kill"             
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {name.title()}"
                                cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                cc += "\n⇒Note: Failed Kill"
                                arif.sendTag(to, cc, [x])
                            else:
                                cc = "【 USER 】"
                                cc += "\nType: Kill"             
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {name.title()}"
                                cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                cc += "\n⇒Note: Success Kill"
                                arif.sendTag(to, cc, [x])
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Kill"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [x]) 
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if bb._from in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][bb._from]
                            arif.sendMessage(to, "Please Wait")
                            if checkScreen(name) == True:
                                os.system('screen -R {} -X quit'.format(str(name)))
                            time.sleep(2)
                            if checkScreen(name) == True:
                                cc = "【 USER 】"
                                cc += "\nType: Kill"             
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {name.title()}"
                                cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                cc += "\n⇒Note: Failed Kill"
                                arif.sendTag(to, cc, [bb._from])
                            else:
                                cc = "【 USER 】"
                                cc += "\nType: Kill"             
                                cc += "\n⇒User: @!"
                                cc += f"\n⇒Name: {name.title()}"
                                cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                cc += "\n⇒Note: Success Kill"
                                arif.sendTag(to, cc, [bb._from])
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Kill"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [bb._from]) 
                    else:
                        ktl = cmd.split(" ")
                        mmk = cmd.replace(ktl[0] + " ","") 
                        tol = mmk.split(" ")
                        target = tol[0]
                        if target == "all":
                            usermid = [i for i in defaultJson['role']['user']]
                            arif.sendMessage(to, "Please Wait")
                            for xx in usermid:
                                name = defaultJson['role']['user'][xx]
                                if checkScreen(name) == True:
                                    os.system('screen -R {} -X quit'.format(str(name)))
                                time.sleep(2)
                            cc = "【 USER 】"
                            cc += "\nType: Kill"             
                            cc += "\n⇒User: All"
                            cc += "\n⇒Note: Success Kill"
                            arif.sendMessage(to, cc)
                        else:
                            for xxx in target.split(","):
                                miduser =  defaultJson['role']['info'][xxx]['mid']
                                if miduser in defaultJson['role']['user']:
                                    name = defaultJson['role']['user'][miduser]
                                    arif.sendMessage(to, "Please Wait")
                                    if checkScreen(name) == True:
                                        os.system('screen -R {} -X quit'.format(str(name)))     
                                    time.sleep(2)
                                    if checkScreen(name) == True:
                                        cc = "【 USER 】"
                                        cc += "\nType: Kill"             
                                        cc += "\n⇒User: @!"
                                        cc += f"\n⇒Name: {name.title()}"
                                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                        cc += "\n⇒Note: Failed Kill"
                                        arif.sendTag(to, cc, [miduser])
                                    else:
                                        cc = "【 USER 】"
                                        cc += "\nType: Kill"             
                                        cc += "\n⇒User: @!"
                                        cc += f"\n⇒Name: {name.title()}"
                                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                        cc += "\n⇒Note: Success Kill"
                                        arif.sendTag(to, cc, [miduser])
                                else:
                                    cc = "【 USER 】"
                                    cc += "\nType: Kill"             
                                    cc += "\n⇒Name: {xxx.title()}"
                                    cc += "\n⇒Note: Nothing User"
                                    arif.sendMessage(to, cc)

        elif cmd == 'time user' or commandMen(msg, text, 'time user'):
            if msg._from in bos or msg._from in own:
                namasb = []
                usermid = [a for a in defaultJson['role']['user']]
                for x in usermid:
                    namasb.append(x)
                mids = eval(str(namasb))
                result = '【 USER 】'
                result += '\nType: Expired'
                no = 0
                for i in range(len(mids)//20+1):
                    target = []
                    for mid in mids[i*20:(i+1)*20]:
                        name = defaultJson['role']['user'][mid]
                        datee = parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")
                        timee = parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%H:%M:%S WIB")
                        no += 1
                        if namasb and mid == namasb[0]:
                            result += '\nSB:\n'
                        result += f'{no}. User: @!\n'      
                        result += f'  ⇒Nama: {name.title()}\n'
                        result += f'  ⇒Date: {datee}\n'
                        result += f'  ⇒Time: {timee}\n'
                        if mid == mids[-1]:
                            result += "\n\nCommand:"
                            result += f"\n⇒{setKey.title()} Addday ‹D› ‹N/R/@/A›"
                            result += f"\n⇒{setKey.title()} Delday ‹D› ‹N/R/@/A›"
                            result += f"\n⇒{setKey.title()} Addtime ‹T› ‹N/R/@/A›"
                            result += f"\n⇒{setKey.title()} Deltime ‹T› ‹N/R/@/A›"
                            result += "\n\nTrigger:"
                            result += "\n⇒D = Amount Day"
                            result += "\n⇒T = Amount Time"
                            result += "\n⇒N = Name"
                            result += "\n⇒R = Reply"
                            result += "\n⇒@ = Tag"
                            result += f"\n\n® {settings['team']}"
                        target.append(mid)
                    if result.startswith('\n'): result = result[1:]
                    if result.endswith('\n'): result = result[:-1]
                    arif.sendTag(to, result, target)
                    result = ''

        elif cmd.startswith("addday"):
            if msg._from in bos or msg._from in own:                
                ktl = text.split("day ")
                mmk = text.replace(ktl[0] + "day ","")
                tol = mmk.split(" ")
                hari = int(tol[0])
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    for x in list:
                        if x in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][x]
                            defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])+timedelta(days=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Addday"             
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {name.title()}"
                            cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                            cc += "\n⇒Note: Success Addday"
                            arif.sendTag(to, cc, [x]) 
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Addday"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [x]) 
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if bb._from in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][bb._from]
                            defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])+timedelta(days=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Addday"             
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {name.title()}"
                            cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                            cc += "\n⇒Note: Success Addday"
                            arif.sendTag(to, cc, [bb._from]) 
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Addday"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [bb._from])  
                    else:
                        ktl = cmd.split(" ")
                        mmk = cmd.replace(ktl[0] + " ","") 
                        tol = mmk.split(" ")
                        hari = int(tol[0])
                        target = tol[1]
                        if target == "all":
                            usermid = [i for i in defaultJson['role']['user']]
                            for xx in usermid:
                                name = defaultJson['role']['user'][xx]
                                defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])+timedelta(days=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Addday"             
                            cc += "\n⇒User: All"
                            cc += "\n⇒Note: Success Addday"
                            arif.sendMessage(to, cc)
                        else:
                            for xxx in target.split(","):
                                miduser =  defaultJson['role']['info'][xxx]['mid']
                                if miduser in defaultJson['role']['user']:
                                    name = defaultJson['role']['user'][miduser]
                                    defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])+timedelta(days=hari))
                                    cc = "【 USER 】"
                                    cc += "\nType: Addday"             
                                    cc += "\n⇒User: @!"
                                    cc += f"\n⇒Name: {name.title()}"
                                    cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                    cc += "\n⇒Note: Success Addday"
                                    arif.sendTag(to, cc, [miduser]) 
                                else:
                                    cc = "【 USER 】"
                                    cc += "\nType: Addday"             
                                    cc += "\n⇒Name: {xxx.title()}"
                                    cc += "\n⇒Note: Nothing User"
                                    arif.sendMessage(to, cc)

        elif cmd.startswith("delday"):
            if msg._from in bos or msg._from in own:                
                ktl = text.split("day ")
                mmk = text.replace(ktl[0] + "day ","")
                tol = mmk.split(" ")
                hari = int(tol[0])
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    for x in list:
                        if x in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][x]
                            defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])-timedelta(days=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Delday"             
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {name.title()}"
                            cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                            cc += "\n⇒Note: Success Delday"
                            arif.sendTag(to, cc, [x]) 
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Delday"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [x]) 
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if bb._from in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][bb._from]
                            defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])-timedelta(days=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Delday"             
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {name.title()}"
                            cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                            cc += "\n⇒Note: Success Delday"
                            arif.sendTag(to, cc, [bb._from]) 
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Delday"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [bb._from])  
                    else:
                        ktl = cmd.split(" ")
                        mmk = cmd.replace(ktl[0] + " ","") 
                        tol = mmk.split(" ")
                        hari = int(tol[0])
                        target = tol[1]
                        if target == "all":
                            usermid = [i for i in defaultJson['role']['user']]
                            for xx in usermid:
                                name = defaultJson['role']['user'][xx]
                                defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])-timedelta(days=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Delday"             
                            cc += "\n⇒User: All"
                            cc += "\n⇒Note: Success Delday"
                            arif.sendMessage(to, cc)
                        else:
                            for xxx in target.split(","):
                                miduser =  defaultJson['role']['info'][xxx]['mid']
                                if miduser in defaultJson['role']['user']:
                                    name = defaultJson['role']['user'][miduser]
                                    defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])-timedelta(days=hari))
                                    cc = "【 USER 】"
                                    cc += "\nType: Delday"             
                                    cc += "\n⇒User: @!"
                                    cc += f"\n⇒Name: {name.title()}"
                                    cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%d-%m-%Y")}'
                                    cc += "\n⇒Note: Success Delday"
                                    arif.sendTag(to, cc, [miduser]) 
                                else:
                                    cc = "【 USER 】"
                                    cc += "\nType: Delday"             
                                    cc += "\n⇒Name: {xxx.title()}"
                                    cc += "\n⇒Note: Nothing User"
                                    arif.sendMessage(to, cc)

        elif cmd.startswith("addtime"):
            if msg._from in bos or msg._from in own:                
                ktl = cmd.split(" ")
                mmk = cmd.replace(ktl[0] + " ","")
                tol = mmk.split(" ")
                hari = int(tol[0])
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    for x in list:
                        if x in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][x]
                            defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])+timedelta(hours=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Addtime"             
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {name.title()}"
                            cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%H:%M:%S WIB")}'
                            cc += "\n⇒Note: Success Addtime"
                            arif.sendTag(to, cc, [x]) 
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Addtime"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [x]) 
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if bb._from in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][bb._from]
                            defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])+timedelta(hours=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Addtime"             
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {name.title()}"
                            cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%H:%M:%S WIB")}'
                            cc += "\n⇒Note: Success Addtime"
                            arif.sendTag(to, cc, [bb._from]) 
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Addtime"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [bb._from])  
                    else:
                        ktl = cmd.split(" ")
                        mmk = cmd.replace(ktl[0] + " ","") 
                        tol = mmk.split(" ")
                        hari = int(tol[0])
                        target = tol[1]
                        if target == "all":
                            usermid = [i for i in defaultJson['role']['user']]
                            for xx in usermid:
                                name = defaultJson['role']['user'][xx]
                                defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])+timedelta(hours=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Addtime"             
                            cc += "\n⇒User: All"
                            cc += "\n⇒Note: Success Addtime"
                            arif.sendMessage(to, cc)
                        else:
                            for xxx in target.split(","):
                                miduser =  defaultJson['role']['info'][xxx]['mid']
                                if miduser in defaultJson['role']['user']:
                                    name = defaultJson['role']['user'][miduser]
                                    defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])+timedelta(hours=hari))
                                    cc = "【 USER 】"
                                    cc += "\nType: Addtime"             
                                    cc += "\n⇒User: @!"
                                    cc += f"\n⇒Name: {name.title()}"
                                    cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%H:%M:%S WIB")}'
                                    cc += "\n⇒Note: Success Addtime"
                                    arif.sendTag(to, cc, [miduser]) 
                                else:
                                    cc = "【 USER 】"
                                    cc += "\nType: Addtime"             
                                    cc += "\n⇒Name: {xxx.title()}"
                                    cc += "\n⇒Note: Nothing User"
                                    arif.sendMessage(to, cc)

        elif cmd.startswith("deltime"):
            if msg._from in bos or msg._from in own:                
                ktl = cmd.split(" ")
                mmk = cmd.replace(ktl[0] + " ","")
                tol = mmk.split(" ")
                hari = int(tol[0])
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    list = geTmention(msg)
                    for x in list:
                        if x in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][x]
                            defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])-timedelta(hours=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Deltime"             
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {name.title()}"
                            cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%H:%M:%S WIB")}'
                            cc += "\n⇒Note: Success Deltime"
                            arif.sendTag(to, cc, [x]) 
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Deltime"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [x]) 
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if bb._from in defaultJson['role']['user']:
                            name = defaultJson['role']['user'][bb._from]
                            defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])-timedelta(hours=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Deltime"             
                            cc += "\n⇒User: @!"
                            cc += f"\n⇒Name: {name.title()}"
                            cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%H:%M:%S WIB")}'
                            cc += "\n⇒Note: Success Deltime"
                            arif.sendTag(to, cc, [bb._from]) 
                        else:
                            cc = "【 USER 】"
                            cc += "\nType: Deltime"             
                            cc += "\n⇒User: @!"
                            cc += "\n⇒Note: Nothing User"
                            arif.sendTag(to, cc, [bb._from])  
                    else:
                        ktl = cmd.split(" ")
                        mmk = cmd.replace(ktl[0] + " ","") 
                        tol = mmk.split(" ")
                        hari = int(tol[0])
                        target = tol[1]
                        if target == "all":
                            usermid = [i for i in defaultJson['role']['user']]
                            for xx in usermid:
                                name = defaultJson['role']['user'][xx]
                                defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])-timedelta(hours=hari))
                            cc = "【 USER 】"
                            cc += "\nType: Deltime"             
                            cc += "\n⇒User: All"
                            cc += "\n⇒Note: Success Delday"
                            arif.sendMessage(to, cc)
                        else:
                            for xxx in target.split(","):
                                miduser =  defaultJson['role']['info'][xxx]['mid']
                                if miduser in defaultJson['role']['user']:
                                    name = defaultJson['role']['user'][miduser]
                                    defaultJson['role']['info'][name]['expired'] = str(parser.parse(defaultJson['role']['info'][name]['expired'])-timedelta(hours=hari))
                                    cc = "【 USER 】"
                                    cc += "\nType: Deltime"             
                                    cc += "\n⇒User: @!" 
                                    cc += f"\n⇒Name: {name.title()}"
                                    cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][name]["expired"]).strftime("%H:%M:%S WIB")}'
                                    cc += "\n⇒Note: Success Deltime"
                                    arif.sendTag(to, cc, [miduser]) 
                                else:
                                    cc = "【 USER 】"
                                    cc += "\nType: Deltime"            
                                    cc += "\n⇒Name: {xxx.title()}"
                                    cc += "\n⇒Note: Nothing User"
                                    arif.sendMessage(to, cc)

        elif cmd.startswith("addme") or commandMen(msg, text, 'addme'):
            if msg._from in bos or msg._from in own:                
                ktl = text.split("dme ")
                mmk = text.replace(ktl[0] + "dme ","")
                tol = mmk.split(" ")
                type = tol[0]
                namee = tol[1]
                if type == "sb":
                    if sender not in defaultJson['role']['user']:
                        defaultJson['role']['user'][sender] = namee
                        defaultJson['role']['info'][namee] = {
                            'group':to,
                            'mid': sender,
                            'authToken': '',
                            'cert':'',
                            'json': {},
                            'appType': '',
                            'expired':str(datetime.now(tz=pytz.timezone("Asia/Jakarta"))+timedelta(days=30))
                        }
                        time.sleep(0.5)
                        cc = "【 USER 】"
                        cc += "\nType: Addsb"             
                        cc += "\n⇒User: @!"
                        cc += f"\n⇒Name: {namee.title()}"
                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][namee]["expired"]).strftime("%d-%m-%Y")}'
                        cc += "\n⇒Note: New User"
                        arif.sendTag(to, cc, [sender])
                    else:
                        xnm = defaultJson['role']['user'][sender]
                        cc = "【 USER 】"
                        cc += "\nType: Addsb"             
                        cc += "\n⇒User: @!"
                        cc += f"\n⇒Name: {xnm.title()}"
                        cc += f'\n⇒Expired: {parser.parse(defaultJson["role"]["info"][xnm]["expired"]).strftime("%d-%m-%Y")}'
                        cc += "\n⇒Note: Already"
                        arif.sendTag(to, cc, [sender])

        elif cmd == 'profile' or commandMen(msg, text, 'profile'):
            if msg._from in bos or msg._from in own:
                bb = "【 PROFILE 】"
                bb += "\nType: Helper"         
                bb += "\n⇒Key ‹T›"
                bb += "\n⇒Key ‹S›"
                bb += f"\n⇒{setKey.title()} Changename ‹T›"
                bb += f"\n⇒{setKey.title()} Changebio ‹T›"
                bb += f"\n⇒{setKey.title()} Changelebel ‹T›"
                bb += f"\n⇒{setKey.title()} Changepict ‹R›"
                bb += f"\n⇒{setKey.title()} Changecover ‹R›"
                bb += f"\n⇒{setKey.title()} Changevp ‹R›"
                bb += f"\n⇒{setKey.title()} Changevc ‹R›"
                bb += "\n\nTrigger:"
                bb += "\n⇒T : Text"
                bb += "\n⇒S : On/Off"
                bb += "\n⇒R : Reply"
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif txt.startswith("key") or commandMen(msg, text, 'key'):
            if msg._from in bos or msg._from in own:
                if mmk == 'on':
                    if settings['setKey']['status']:
                        arif.sendMessage(to, 'Already♪')               
                    else:
                        settings['setKey']['status'] = True
                        arif.sendMessage(to, 'Active♪')                               
                elif mmk == 'off':
                    if not settings['setKey']['status']:
                        arif.sendMessage(to, 'Already♪')            
                    else:
                        settings['setKey']['status'] = False
                        arif.sendMessage(to, 'Deactive♪')          
                else:
                    settings['setKey']['key'] = mmk
                    arif.sendMessage(to, 'Done♪')               

        elif cmd.startswith("changename ") or commandMen(msg, text, 'changename'):
            if msg._from in bos or msg._from in own:
                ktl = text.split('changename ')
                mmk = text.replace(ktl[0] + 'changename ','')
                profile = arif.getProfile()
                profile.displayName = str(mmk)
                arif.updateProfile(profile)
                arif.sendMessage(to,"Succes♪")   

        elif cmd.startswith("changelabel ") or commandMen(msg, text, 'changelabel'):
            if msg._from in bos or msg._from in own:
                ktl = text.split('label ')
                mmk = text.replace(ktl[0] + 'label ','')
                b = livejson.File(f'Elfoxbots/setting.json', True, False, 4)
                settings["team"] = mmk
                b["footerlabel"] = mmk
                arif.sendMessage(to,"Succes♪")   

        elif cmd.startswith("changebio ") or commandMen(msg, text, 'changebio'):
            if msg._from in bos or msg._from in own:
                ktl = text.split('changebio ')
                mmk = text.replace(ktl[0] + 'changebio ','')
                profile = arif.getProfile()
                profile.statusMessage = str(mmk)
                arif.updateProfile(profile)
                arif.sendMessage(to,"Succes♪")

        elif cmd == 'changepict' or commandMen(msg, text, 'changepict'):
            if msg._from in bos or msg._from in own:
                ktl = geTreply(msg)
                if ktl.contentType == 1:
                    path = arif.downloadObjectMsg(ktl.id)
                    arif.updateProfilePicture(path)
                    arif.sendMessage(to,"Succes♪")

        elif cmd == 'changecover' or commandMen(msg, text, 'changecover'):
            if msg._from in bos or msg._from in own:
                ktl = geTreply(msg)
                if ktl.contentType == 1:
                    path = arif.downloadObjectMsg(ktl.id)
                    arif.updateProfileCover(path)
                    arif.sendMessage(to,"Succes♪")

        elif cmd == "changevc" or commandMen(msg, text, 'changevc'):
            if msg._from in bos or msg._from in own:
                ktl = geTreply(msg)
                if ktl.contentType == 2:
                    pict = covernyaa(myMid)
                    path = arif.downloadFileURL(pict)
                    path1 = arif.downloadObjectMsg(ktl.id)
                    arif.updateProfileCoverVideo(path, path1)
                    arif.sendMessage(to,"Succes♪")      

        elif cmd == 'changevp' or commandMen(msg, text, 'changevp'):
            if msg._from in bos or msg._from in own:
                ktl = geTreply(msg)
                if ktl.contentType == 2:
                    pict = "https://obs.line-scdn.net/{}".format(arif.getProfile().pictureStatus)
                    path = arif.downloadFileURL(pict)
                    path1 = arif.downloadObjectMsg(ktl.id)
                    changevideopp(path, path1)
                    arif.sendMessage(to,"Succes♪")         

        elif cmd == 'group':
            if msg._from in bos or msg._from in own:
                bb = "【 GROUP 】"
                bb += "\nType: Helper"       
                bb += f"\n⇒{setKey.title()} Forum"
                bb += f"\n⇒{setKey.title()} Grouplist"
                bb += f"\n⇒{setKey.title()} Grouppenlist"
                bb += f"\n⇒{setKey.title()} Openqr"
                bb += f"\n⇒{setKey.title()} Closeqr"
                bb += f"\n⇒{setKey.title()} Byehelper"
                bb += f"\n⇒{setKey.title()} Kick ‹@/R›"
                bb += f"\n⇒{setKey.title()} Invite ‹@/R›"
                bb += "\n\nTrigger:"
                bb += "\n⇒@ : Tag"
                bb += "\n⇒R : Reply"
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif cmd.startswith("forum"):
            if msg._from in bos or msg._from in own:
                ktl = cmd.split(' ')
                mmk = cmd.replace(ktl[0] + ' ','')  
                if cmd == 'forum':
                    ma = ""
                    a = 0
                    for x in settings["forum"]:
                        a = a + 1
                        end = '\n'
                        ma += "⇒" + str(a) + ". " +arif.getChats([x]).chats[0].chatName+ "\n"
                    bb = "【 FORUM 】"
                    bb += "\nType: List"   
                    if ma == '':     
                        bb += "\n⇒Nothing"
                    else:
                        bb += f"\n{ma}"
                    bb += "\n\nCommand:"
                    bb += f"\n⇒{setKey.title()} Forum Add"
                    bb += f"\n⇒{setKey.title()} Forum Del"
                    bb += f"\n⇒{setKey.title()} Forum Clear"
                    bb += f"\n\n® {settings['team']}"
                    arif.sendMessage(to, bb)
                elif mmk == 'add':
                    if to in settings['forum']:
                        arif.sendMessage(to,"Already♪")           
                    else:
                        settings['forum'].append(to)
                        arif.sendMessage(to,"Succes♪")           
                elif mmk == 'del':
                    if to not in settings['forum']:
                        arif.sendMessage(to,"Already♪")           
                    else:
                        settings['forum'].remove(to)
                        arif.sendMessage(to,"Succes♪")                       
                elif mmk == 'clear':
                    if len(settings["forum"]) > 0:
                        settings["forum"].clear()              
                        arif.sendMessage(to,"Done♪")
                    else:
                        arif.sendMessage(to,"Nothing♪")

        elif cmd == 'grouplist' or commandMen(msg, text, 'grouplist'):
            if msg._from in bos or msg._from in own:
                if len(arif.getAllChatMids(True, True).memberChatMids) > 0:
                    h = [sange for sange in arif.getAllChatMids(True, True).memberChatMids]
                    k = len(h)//100    
                    for aa in range(k+1):
                        if aa == 0:
                            dd = '【 GROUPLIST 】\nType: List'
                            no=aa
                        else:
                            dd = ''
                            no=aa*100
                        msgas = dd
                        for a in h[aa*100:(aa+1)*100]:
                            cuk = arif.getChats([a], True , False).chats[0]
                            no+=1
                            if no == len(h):
                                msgas+="\n⇒{}. {} {}".format(no , cuk.chatName[0:25], len(cuk.extra.groupExtra.memberMids))                   
                            else:
                                msgas += "\n⇒{}. {} {}".format(no , cuk.chatName[0:25], len(cuk.extra.groupExtra.memberMids))      
                        ret = msgas
                        ret += "\n\nRemote:"
                        ret += "\n⇒Leave ‹N›"
                        ret += "\n⇒Inviteme ‹N›"
                        ret += "\n⇒Openqr ‹N›"
                        ret += "\n⇒Closeqr ‹N›"
                        ret += "\n\nTrigger:"
                        ret += "\n⇒N: Number"
                        ret += f"\n\n® {settings['team']}"
                        arif.sendMessage(to, ret)
                else:arif.sendMessage(to,"Nothing♪")                 

        if cmd.startswith("leave "):
            if msg._from in bos or msg._from in own:
                gid = [sange for sange in arif.getAllChatMids(True, True).memberChatMids]
                if len(cmd.split(" ")) == 2:
                    selection = MySplit(cmd.split(' ')[1],range(1,len(gid)+1));k = len(gid)//100            
                    for a in range(k+1):
                        if a == 0:ajg='【 GROUPLIST 】\nType: Leave'
                        else:ajg='Nothing♪'
                        babi = '';no = 0                
                        for i in selection.parse()[a*100 : (a+1)*100]:
                            leaveed(gid[i - 1]);time.sleep(0.4);no+=1;gC = arif.getChats([gid[i - 1]], True , False).chats[0]                                        
                            if no == len(selection.parse()):babi+= "\n⇒{}. {}".format(i,gC.chatName)
                            else:babi+= "\n⇒{}. {}".format(i,gC.chatName)
                        arif.sendMessage(to,ajg+babi)

        elif cmd.startswith("inviteme "):
            if msg._from in bos or msg._from in own:
                separate = cmd.split(" ")
                num = cmd.replace(separate[0] + " ","")
                groups = [a for a in arif.getAllChatMids(True, True).memberChatMids]
                if groups is not None:
                    if int(num) <= len(groups):
                        groupid = groups[int(num) - 1]
                        group = arif.getChats([groupid]).chats[0]
                        try:
                            invited(groupid, sender)
                            arif.sendMessage(to,"Done♪")
                        except Exception as e:
                            arif.sendMessage(to,"Limited♪")

        elif cmd.startswith("openqr "):
            if msg._from in bos or msg._from in own:
                sep = cmd.split(" ")
                num = cmd.replace(sep[0] + " ","")
                gids = [sange for sange in arif.getAllChatMids(True, True).memberChatMids]
                gid = gids[int(num) - 1]
                tol = qrOpen(gid)
                if tol:
                    bb = "【 GROUPLIST 】"
                    bb += "\nType: Openqr"    
                    bb += "\nLink:"    
                    bb += f"\nline://ti/g/{tol}"     
                    arif.sendMessage(to,bb)

        elif cmd.startswith("closeqr "):
            if msg._from in bos or msg._from in own:
                sep = cmd.split(" ")
                num = cmd.replace(sep[0] + " ","")
                gids = [sange for sange in arif.getAllChatMids(True, True).memberChatMids]
                gid = gids[int(num) - 1]
                qrClose(gid)
                bb = "【 GROUPLIST 】"
                bb += "\nType: Closeqr"    
                bb += "\n⇒Note: Succes Closeqr"    
                arif.sendMessage(to, str(bb))

        elif cmd == 'grouppenlist' or commandMen(msg, text, 'grouppenlist'):
            if msg._from in bos or msg._from in own:
                if len(arif.getAllChatMids(True, True).invitedChatMids) > 0:
                    h = [sange for sange in arif.getAllChatMids(True, True).invitedChatMids]
                    k = len(h)//100    
                    for aa in range(k+1):
                        if aa == 0:
                            dd = '【 GROUP PENDING LIST 】\nType: List'
                            no=aa
                        else:
                            dd = ''
                            no=aa*100
                        msgas = dd
                        for a in h[aa*100:(aa+1)*100]:
                            cuk = arif.getChats([a], True , False).chats[0]
                            no+=1
                            if no == len(h):
                                msgas+="\n⇒{}. {} {}".format(no , cuk.chatName[0:25], len(cuk.extra.groupExtra.memberMids))                   
                            else:
                                msgas += "\n⇒{}. {} {}".format(no , cuk.chatName[0:25], len(cuk.extra.groupExtra.memberMids))      
                        ret = msgas
                        ret += "\n\nRemote:"
                        ret += "\n⇒Accept ‹N/A›"
                        ret += "\n⇒Reject ‹N/A›"
                        ret += "\n\nTrigger:"
                        ret += "\n⇒N: Number"
                        ret += "\n⇒A: All"
                        ret += f"\n\n® {settings['team']}"
                        arif.sendMessage(to, ret)
                else:arif.sendMessage(to,"Nothing♪")                 

        elif cmd.startswith("reject"):
            if msg._from in bos or msg._from in own:
                ktl = cmd.split(' ');mmk = cmd.replace(ktl[0] + ' ','')       
                if mmk == "all":
                    ginvited = [sange for sange in arif.getAllChatMids(True, True).invitedChatMids]
                    if ginvited != [] and ginvited != None:
                        for gid in ginvited:
                            rejected(gid)
                        arif.sendMessage(to,"Done {}♪".format(str(len(ginvited))))
                    else:arif.sendMessage(to,"Nothing♪") 
                else:  
                    sep = cmd.split(" ")
                    number = cmd.replace(sep[0] + " ","")           
                    for ajg in number.split(","):
                        groups = [sange for sange in arif.getAllChatMids(True, True).invitedChatMids]
                        try:
                            group = groups[int(ajg)-1]
                            G = arif.getChats([group], True , False).chats[0]                   
                            try:
                                rejected(G.chatMid)
                            except:
                                rejected(G.chatMid)
                            arif.sendMessage(to,"Done♪") 
                        except Exception as error:arif.sendMessage(to,"Nothing♪") 

        elif cmd.startswith("accept"):
            if msg._from in bos or msg._from in own:
                ktl = cmd.split(' ');mmk = cmd.replace(ktl[0] + ' ','')       
                if mmk == "all":
                    ginvited = [sange for sange in arif.getAllChatMids(True, True).invitedChatMids]
                    if ginvited != [] and ginvited != None:
                        for gid in ginvited:arif.acceptChatInvitation(gid)                   
                        arif.sendMessage(to,"Done {}♪".format(str(len(ginvited))))
                    else:arif.sendMessage(to,"Nothing♪") 
                else:  
                    sep = cmd.split(" ")
                    number = cmd.replace(sep[0] + " ","")           
                    for ajg in number.split(","):
                        groups = [sange for sange in arif.getAllChatMids(True, True).invitedChatMids]
                        try:
                            group = groups[int(ajg)-1]
                            G = arif.getChats([group], True , False).chats[0]                                       
                            try:
                                accepted(G.chatMid)                       
                            except:
                                accepted(G.chatMid)                       
                            arif.sendMessage(to,"Done♪") 
                        except Exception as error:arif.sendMessage(to,"Nothing♪") 

        elif cmd == 'openqr':
            if msg._from in bos or msg._from in own:
                tol = qrOpen(to)
                if tol:
                    bb = "【 GROUP 】"
                    bb += "\nType: Openqr"    
                    bb += "\nLink:"    
                    bb += f"\nline://ti/g/{tol}"     
                    arif.sendMessage(to,bb)
   
        elif cmd == 'closeqr':
            if msg._from in bos or msg._from in own:
                qrClose(to)
                bb = "【 GROUP 】"
                bb += "\nType: Closeqr"    
                bb += "\n⇒Note: Succes Closeqr"    
                arif.sendMessage(to, str(bb))
   
        elif cmd.startswith("kick"):
            if msg._from in bos or msg._from in own:
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    lists = geTmention(msg)
                    for x in lists:
                        kicked(to, x)                                  
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if cmd == "kick":
                            kicked(to, bb._from)                  
                   
        elif cmd.startswith("invite"):
            if msg._from in bos or msg._from in own:
                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata.keys():                               
                    lists = geTmention(msg)
                    for x in lists:
                        invited(to, x)                                            
                else:
                    if msg.relatedMessageId is not None:
                        bb = geTreply(msg)
                        if cmd == "invite":
                            invited(to, bb._from)             
       
        elif cmd == "byehelper" or commandMen(msg, text, 'byehelper'):
            if msg._from in bos or msg._from in own:
                arif.sendContact(to, 'u6459106c8251205f79c2f037cd99b6a4') 
                arif.sendMessage(to, "Good Bye " +str(arif.getChats([to]).chats[0].chatName))
                leaveed(to)    

        elif cmd == 'file' or commandMen(msg, text, 'file'):
            if msg._from in bos:
                bb = "【 FILE 】"
                bb += "\nType: Helper"       
                bb += f"\n⇒{setKey.title()} Listfile"
                bb += f"\n⇒{setKey.title()} Updatejson ‹TY/UP/BL›"
                bb += f"\n⇒{setKey.title()} Broadcast ‹T›"
                bb += "\n\nTrigger:"
                bb += "\n⇒TY: Type"
                bb += "\n⇒UP: Update"
                bb += "\n⇒BL: Bool"
                bb += "\n⇒T: Text"
                bb += "\n⇒S: On/Off"
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif cmd.startswith("updatejson "):
            if msg._from in bos:
                ktl = text.split('updatejson ')
                mmk = text.replace(ktl[0] + 'updatejson ','')
                ajg = mmk.split(" | ")
                type = ajg[0]
                update = ajg[1]
                strr = ajg[2]
                h = [a for a in defaultJson['role']['user']]
                k = len(h)
                if strr == "bool":
                    strrr = False
                elif strr == "list":
                    strrr = []
                elif strr == "string":
                    strrr = {}
                else:
                    strrr = strr       
                for aa in range(k+1):
                    if aa==0:no=aa
                    else:no=aa
                    for a in h[aa : (aa + 1)]:
                        name = defaultJson['role']['user'][a]
                        a = livejson.File(f'user/{name}/{type}.json', True, False, 4)
                        b = livejson.File(f'Elfoxbots/{type}.json', True, False, 4)
                        a[update] = strrr
                        b[update] = strrr
                arif.sendMessage(to, "Done♪")   
  

        elif cmd == 'listfile' or commandMen(msg, text, 'listfile'):
            if msg._from in bos:
                am = subprocess.getoutput('ls user')
                bb = "【 FILE 】"
                bb += "\nType: List"  
                bb += "\nFile Name:"  
                bb += f"\n{am}"
                bb += "\n\nCommand:"
                bb += f"\n⇒{setKey.title()} Delfile ‹N›"
                bb += "\n\nTrigger:"
                bb += "\n⇒N: Name"
                bb += f"\n\n® {settings['team']}"
                arif.sendMessage(to, bb)

        elif cmd.startswith("delfile "):
            if msg._from in bos:
                ktl = cmd.split(' ')
                mmk = cmd.replace(ktl[0] + ' ','')
                for asu in mmk.split(","):
                    os.system(f'rm -rf user/{asu}')
                arif.sendMessage(to, "Done♪")

        elif cmd.startswith("broadcast "):
            if msg._from in bos:
                ktl = cmd.split(' ')
                mmk = cmd.replace(ktl[0] + ' ','')
                bb = "【 BROADCAST 】"
                bb += "\nFrom: Creator"       
                bb += "\nTo: @!"       
                bb += "\nMessage:"
                bb += f"\n{mmk}"
                a = defaultJson['role']['user']
                for x in a:
                    time.sleep(1)
                    arif.sendTag(x, bb, [x])
                time.sleep(1)        
                arif.sendMessage(to, "Done♪")
#==================??𝙄𝙉??𝙎𝙃====================
def executeOp(op):
    try:
        print ('› Operation: %i %s elfoxbsd15 Helper' % (op.type, OpType._VALUES_TO_NAMES[op.type].replace('_', ' ')))
        if op.type in [5]:
            notified_add(op)
        if op.type in [13, 124]:
            notified_invited(op)
        if op.type in [26]:
            notified_operation(op)                       
    except TalkException as talk_error:
        logError(talk_error)
        if talk_error.code in [7, 8, 20]:
            sys.exit(1)
    except KeyboardInterrupt:
        sys.exit('##---- KEYBOARD INTERRUPT -----##')
    except Exception as error:
        logError(error)

def userTime(op):
    for duit in defaultJson['role']['user']:
        folder = defaultJson['role']['user'][duit]
        data = defaultJson['role']['info'][folder]
        waktu = data["expired"]
        forum = settings["forum"]
        if datetime.now(tz=pytz.timezone("Asia/Jakarta")) > parser.parse(waktu):
            a = os.popen("screen -list").read()
            if folder in a:
                os.system("screen -S {} -X quit".format(folder))
                time.sleep(1)
            del defaultJson['role']['user'][duit] 
            del defaultJson['role']['info'][folder]  
            arif.sendMessage(duit, " You Selfbot Expired, Please Chat Owner For Renew Selfbot")
            ret = "【 USER 】"
            ret += "\nType: Expired"
            ret += "\n⇒User: @!"
            ret += f"\n⇒Time: {parser.parse(waktu).strftime('%d-%m-%Y (%H:%M:%S)')}"
            for x in forum:
                arif.sendTag(x, ret, [duit])

def runningProgram():
    if settings['restartPoint'] is not None:
        try:
            arif.sendMessage(settings['restartPoint'], 'Done♪')
        except TalkException:
            pass
        settings['restartPoint'] = None
    while True:
        try:
            ops = arif.poll.fetchOps(oepoll.localRev, 15, oepoll.globalRev, oepoll.individualRev)
            for op in ops:
                if op.revision == -1 and op.param2 != None:
                    oepoll.globalRev = int(op.param2.split("\x1e")[0])
                if op.revision == -1 and op.param1 != None:
                   oepoll.individualRev = int(op.param1.split("\x1e")[0])
                oepoll.localRev = max(op.revision, oepoll.localRev)
                t1 = threading.Thread(target=executeOp(op,))
                t1.start()
                t1.join()
                t2 = threading.Thread(target=userTime(op,))
                t2.start()
                t2.join()
        except Exception as e:
            e = traceback.format_exc()
            if "EOFError" in e:pass
            elif "ShouldSyncException" in e or "LOG_OUT" in e:
                python3 = sys.executable
                os.execl(python3, python3, *sys.argv)
            else:
               traceback.print_exc()
if __name__ == '__main__':
    print ('##---- RUNNING PROGRAM -----##')
    runningProgram()