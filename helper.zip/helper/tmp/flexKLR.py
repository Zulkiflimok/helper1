'''
KALERA TEAM FLEX.
THANK TO: 
• SLASH CORPS
• AUTO BOTS
• A CODE 44
'''
import threading
class template(threading.Thread):
    def __init__(self, client):
        self.client = client

    def kaleraHelp(self, clicks, userpict, username, commands):
        data = [
            {"type": "bubble", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/N7cK77k/Moris-Help.png", "size": "full", "aspectMode": "cover", "aspectRatio": "768:884", "animated": True, "action": {"type": "uri", "uri": clicks } } ] }, {"type": "box","layout": "vertical","contents": [{"type": "image","url":"https://i.ibb.co/5LzVcx3/Perak-Putar.png","animated": True,"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "112px","height": "112px","borderWidth": "0px","borderColor": "#808080","cornerRadius": "100px","offsetTop": "10.5px","offsetStart": "8.5px"}, {"type": "box","layout": "vertical","contents": [{"type": "image","url":"https://i.ibb.co/KK5xG9C/Cahaya.png","animated": True,"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "70.5px","height": "70.5px","borderWidth": "0px","borderColor": "#808080","cornerRadius": "100px","offsetBottom": "9px","offsetEnd": "8px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": userpict, "aspectRatio": "1:1", "aspectMode": "cover", "size": "57px", "action": {"type": "uri", "uri": userpict } } ], "position": "absolute", "cornerRadius": "100px", "offsetBottom": "17px", "offsetEnd": "14.6px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": username, "size": "xs", "weight": "bold", "color": "#ffffff", "align": "center"} ], "position": "absolute", "offsetBottom": "27px", "offsetStart": "30px", "width": "185px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[0].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "140px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[1].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "175px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[2].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "210px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[3].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "245px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[4].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "85px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[5].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "120px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[6].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "155px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[7].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "190px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[8].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "225px", "offsetStart": "165px", "width": "100px"} ], "paddingAll": "0px"}, "styles": {"body": {"backgroundColor": "#141414"} } },
            {"type": "bubble", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/N7cK77k/Moris-Help.png", "size": "full", "aspectMode": "cover", "aspectRatio": "768:884", "animated": True, "action": {"type": "uri", "uri": clicks } } ] }, {"type": "box","layout": "vertical","contents": [{"type": "image","url":"https://i.ibb.co/5LzVcx3/Perak-Putar.png","animated": True,"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "112px","height": "112px","borderWidth": "0px","borderColor": "#808080","cornerRadius": "100px","offsetTop": "10.5px","offsetStart": "8.5px"}, {"type": "box","layout": "vertical","contents": [{"type": "image","url":"https://i.ibb.co/KK5xG9C/Cahaya.png","animated": True,"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "70.5px","height": "70.5px","borderWidth": "0px","borderColor": "#808080","cornerRadius": "100px","offsetBottom": "9px","offsetEnd": "8px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": userpict, "aspectRatio": "1:1", "aspectMode": "cover", "size": "57px", "action": {"type": "uri", "uri": userpict } } ], "position": "absolute", "cornerRadius": "100px", "offsetBottom": "17px", "offsetEnd": "14.6px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": username, "size": "xs", "weight": "bold", "color": "#ffffff", "align": "center"} ], "position": "absolute", "offsetBottom": "27px", "offsetStart": "30px", "width": "185px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[9].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "140px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[10].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "175px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[11].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "210px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[12].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "245px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[13].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "85px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[14].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "120px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[15].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "155px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[16].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "190px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[17].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "225px", "offsetStart": "165px", "width": "100px"} ], "paddingAll": "0px"}, "styles": {"body": {"backgroundColor": "#141414"} } },
            {"type": "bubble", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/N7cK77k/Moris-Help.png", "size": "full", "aspectMode": "cover", "aspectRatio": "768:884", "animated": True, "action": {"type": "uri", "uri": clicks } } ] }, {"type": "box","layout": "vertical","contents": [{"type": "image","url":"https://i.ibb.co/5LzVcx3/Perak-Putar.png","animated": True,"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "112px","height": "112px","borderWidth": "0px","borderColor": "#808080","cornerRadius": "100px","offsetTop": "10.5px","offsetStart": "8.5px"}, {"type": "box","layout": "vertical","contents": [{"type": "image","url":"https://i.ibb.co/KK5xG9C/Cahaya.png","animated": True,"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "70.5px","height": "70.5px","borderWidth": "0px","borderColor": "#808080","cornerRadius": "100px","offsetBottom": "9px","offsetEnd": "8px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": userpict, "aspectRatio": "1:1", "aspectMode": "cover", "size": "57px", "action": {"type": "uri", "uri": userpict } } ], "position": "absolute", "cornerRadius": "100px", "offsetBottom": "17px", "offsetEnd": "14.6px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": username, "size": "xs", "weight": "bold", "color": "#ffffff", "align": "center"} ], "position": "absolute", "offsetBottom": "27px", "offsetStart": "30px", "width": "185px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[18].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "140px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[19].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "175px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[20].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "210px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[21].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "245px", "offsetStart": "65px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[22].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "85px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[23].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "120px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[24].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "155px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[25].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "190px", "offsetStart": "165px", "width": "100px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": commands[26].upper(), "color": "#ffffff", "size": "12px", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetTop": "225px", "offsetStart": "165px", "width": "100px"} ], "paddingAll": "0px"}, "styles": {"body": {"backgroundColor": "#141414"} } },
        ]
        return data

    def kaleraStatus(self, settings, userpict, username, bool_dict):
        data = {"type": "bubble","size": "kilo","header": {"type": "box","layout": "vertical","contents": [{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute"},{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute","offsetTop": "255px"},{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute","offsetTop": "520px"},{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute","offsetTop": "780px"},{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute","offsetTop": "1040px"},{"type": "box","layout": "vertical","contents": [],"height": "5px","backgroundColor": "#202020"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://www.linkpicture.com/q/top-kalera_1.png","size": "full","aspectRatio": "40:15.5","aspectMode": "cover","animated": True}] },{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/QrQPJZf/kalera-circle.png","size": "90px","aspectMode": "cover","animated": True},{"type": "box","layout": "vertical","contents": [{"type": "image","url": userpict,"aspectMode": "cover"}],"position": "absolute","cornerRadius": "100px","width": "68px","height": "68px","offsetTop": "11px","offsetStart": "11px"}],"position": "absolute","paddingAll": "0px","cornerRadius": "100px","offsetTop": "2.5px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "STATUS","align": "center","weight": "bold","color": "#FFFFFF","size": "sm"},{"type": "separator","color": "#999999","margin": "2.5px"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "BACKUP WL","color": "#FFFFFF","size": "xxs"},{"type": "image","url": bool_dict[settings['backupwl']][3],"aspectMode": "cover","size": "60px","aspectRatio": "2.5:1","align": "end","animated": True}],"offsetTop": "5px","height": "30px","justifyContent": "center","alignItems": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "BACKUP ADMIN", "color": "#FFFFFF","size": "xxs"},{"type": "image","url": bool_dict[settings['backupadmin']][3],"aspectMode": "cover","size": "60px","aspectRatio": "2.5:1","align": "end","animated": True}],"offsetTop": "5px","height": "30px","justifyContent": "center","alignItems": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "JS","color": "#FFFFFF","size": "xxs"},{"type": "image","url": bool_dict[settings['javascript']][3],"aspectMode": "cover","size": "60px","aspectRatio": "2.5:1","align": "end","animated": True}],"offsetTop": "5px","height": "30px","justifyContent": "center","alignItems": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "MODE PUBLIC","color": "#FFFFFF","size": "xxs"},{"type": "image","url": bool_dict[settings['modepublic']][3],"aspectMode": "cover","size": "60px","aspectRatio": "2.5:1","align": "end","animated": True}],"offsetTop": "5px","height": "30px","justifyContent": "center","alignItems": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "MENTION KICK","color": "#FFFFFF","size": "xxs"},{"type": "image","url": bool_dict[settings['mentionkick']][3],"aspectMode": "cover","size": "60px","aspectRatio": "2.5:1","align": "end","animated": True}],"offsetTop": "5px","height": "30px","justifyContent": "center","alignItems": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "PURGE","color": "#FFFFFF","size": "xxs"},{"type": "image","url": bool_dict[settings['purge']][3],"aspectMode": "cover","size": "60px","aspectRatio": "2.5:1","align": "end","animated": True}],"offsetTop": "5px","height": "30px","justifyContent": "center","alignItems": "center"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "DOWNLOAD MEDIA","color": "#FFFFFF","size": "xxs"},{"type": "image","url": bool_dict[settings['downloadmedia']][3],"aspectMode": "cover","size": "60px","aspectRatio": "2.5:1","align": "end"}],"offsetTop": "5px","height": "30px","justifyContent": "center","alignItems": "center"}],"paddingAll": "10px","backgroundColor": f"{settings['colorlabel']}bb"}],"paddingAll": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://www.linkpicture.com/q/klr-team.png","size": "full","aspectRatio": "38:3.5","aspectMode": "cover","animated": True},{"type": "box","layout": "vertical","contents": [],"height": "4px","backgroundColor": "#202020"}],"paddingAll": "0px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": username,"size": "xs","color": "#FFFFFF"}],"position": "absolute","width": "135px","height": "27.5px","offsetStart": "100px","offsetTop": "45px","justifyContent": "center","alignItems": "center"}],"paddingAll": "0px"},"styles": {"header": {"backgroundColor": "#000000"}}}   
        return data

    def kaleraMain(self, settings, userpict, username, textnya):
        data = {"type": "bubble","size": "kilo","header": {"type": "box","layout": "vertical","contents": [{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute"},{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute","offsetTop": "257.5px"},{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute","offsetTop": "520px"},{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute","offsetTop": "780px"},{"type": "image","url": settings["footerpict"],"size": "full","aspectMode": "cover","aspectRatio": "1:1","position": "absolute","offsetTop": "1040px"},{"type": "box","layout": "vertical","contents": [],"height": "5px","backgroundColor": "#202020"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://www.linkpicture.com/q/top-kalera_1.png","size": "full","aspectRatio": "40:15.5","aspectMode": "cover","animated": True}]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/WD3bWv4/kalera-circle-1.png","size": "90px","aspectMode": "cover","animated": True},{"type": "box","layout": "vertical","contents": [{"type": "image","url": userpict,"aspectMode": "cover"}],"position": "absolute","cornerRadius": "100px","width": "68px","height": "68px","offsetTop": "11px","offsetStart": "11px"}],"position": "absolute","paddingAll": "0px","cornerRadius": "100px","offsetTop": "2.5px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [],"width": "3px","backgroundColor": "#FFFFFF"},{"type": "box","layout": "vertical","contents": [],"width": "7px"},{"type": "text","text": textnya,"color": "#FFFFFF","size": "xs","wrap": True}],"paddingAll": "10px","backgroundColor": f"{settings['colorlabel']}bb"}],"paddingAll": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://www.linkpicture.com/q/klr-team.png","size": "full","aspectRatio": "38:3.5","aspectMode": "cover","animated": True},{"type": "box","layout": "vertical","contents": [],"height": "4px","backgroundColor": "#202020"}],"paddingAll": "0px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": username,"size": "xs","color": "#FFFFFF"}],"position": "absolute","width": "135px","height": "27.5px","offsetStart": "100px","offsetTop": "45px","justifyContent": "center","alignItems": "center"}],"paddingAll": "0px"},"styles": {"header": {"backgroundColor": "#000000"}}}
        return data
 
    def flexyans(self, settings, userpict, username, textnya):
        data = {"type": "bubble", "size": "kilo", "header": {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/5vM71b4/robots-wallpaper.png", "aspectRatio": "75:150", "aspectMode": "cover", "position": "absolute", "size": "full"}, {"type": "image", "url": "https://i.ibb.co/5vM71b4/robots-wallpaper.png", "aspectRatio": "75:150", "aspectMode": "cover", "size": "full", "position": "absolute", "offsetTop": "347.5px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/dDKypRk/top-msg-robots.png", "aspectMode": "cover", "aspectRatio": "215:67.5", "size": "full", "animated": True}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/QX3yxbH/hlth-bluefire.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "animated": True}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": userpict, "aspectMode": "cover"}], "position": "absolute", "width": "60.75px", "height": "60.75px", "cornerRadius": "100px", "offsetTop": "2.275px", "offsetStart": "2.275px"}], "width": "65px", "height": "65px", "position": "absolute", "cornerRadius": "100px", "offsetStart": "30px", "offsetTop": "7.75px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": username, "size": "xxs", "color": "#FFFFFF"}], "width": "110px", "height": "17.5px", "position": "absolute", "offsetStart": "120px", "offsetTop": "34.25px", "justifyContent": "center", "alignItems": "center"}], "paddingAll": "0px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": textnya, "color": "#FFFFFF", "size": "xs", "wrap": True}], "paddingAll": "10px", "backgroundColor": "#50505075", "cornerRadius": "5px"}], "paddingAll": "15px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/SKHfcvR/bottom-robots-msg.png", "aspectMode": "cover", "aspectRatio": "215:50", "size": "full", "animated": True}], "paddingAll": "0px"}], "paddingAll": "0px"} }
        return data

    def flexrobot(self, settings, userpict, username, textnya):
        data = {"type": "bubble","size": "kilo","header": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/DD40GmN/ROBOTS-TOP.png","size": "full","aspectRatio": "50:16.25","aspectMode": "cover"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/Srpv5Ch/ROBOTS-CIRCLE.png","size": "full","aspectMode": "cover","animated": True},{"type": "box","layout": "vertical","contents": [{"type": "image","url": userpict,"size": "full","aspectMode": "cover"}],"position": "absolute","width": "50px","height": "50px","offsetTop": "5px","offsetStart": "5px","cornerRadius": "100px"}],"width": "60px","height": "60px","position": "absolute","offsetTop": "10px","offsetStart": "10px","cornerRadius": "100px","backgroundColor": "#404040"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": username,"color": "#FFFFFF", "size": "xs"}],"position": "absolute","width": "137.5px","height": "20px","offsetTop": "30px","offsetStart": "102.5px","justifyContent": "center","alignItems": "center"}],"paddingAll": "0px"},"hero": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [],"backgroundColor": "#ffffff","width": "2px"},{"type": "box","layout": "vertical","contents": [],"width": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": textnya,"color": "#FFFFFF","size": "sm","wrap": True}]}],"paddingAll": "10px","backgroundColor": "#404040","cornerRadius": "5px"}],"paddingAll": "10px"},"body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/x7bTc8N/ROBOTS-BOTTOM.png","size": "full","aspectRatio": "50:8.5","aspectMode": "cover","animated": True}],"paddingAll": "0px"},"styles": {"header": {"backgroundColor": "#212121"},"hero": {"backgroundColor": "#212121"},"body": {"backgroundColor": "#212121"}}}
        return data

    def yansred(self, settings, userpict, username, textnya):
        data = {"type": "bubble", "size": "kilo", "header": {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/Q9FQx3V/perakbiruslow.png", "aspectRatio": "1:3", "aspectMode": "cover", "position": "absolute", "size": "full","animated": True}, {"type": "image", "url": "https://i.ibb.co/Q9FQx3V/perakbiruslow.png", "aspectRatio": "1:3", "aspectMode": "cover", "position": "absolute", "offsetTop": "347.5px", "size": "full","animated": True}, {"type": "image", "url": "https://i.ibb.co/Q9FQx3V/perakbiruslow.png", "aspectRatio": "1:3", "aspectMode": "cover", "position": "absolute", "offsetTop": "647.5px", "size": "full","animated": True}, {"type": "image", "url": "https://i.ibb.co/Q9FQx3V/perakbiruslow.png", "aspectRatio": "1:3", "aspectMode": "cover", "position": "absolute", "offsetTop": "947.5px", "size": "full","animated": True}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/jGhB2xR/Moris.png", "aspectMode": "cover", "aspectRatio": "9:2", "size": "full", "animated": True}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/vDq3JS1/putar1.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "animated": True}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": userpict, "aspectMode": "cover"}], "position": "absolute", "width": "40px", "height": "40px", "cornerRadius": "100px", "borderWidth": "1px", "borderColor": "#191919", "offsetTop": "3px", "offsetStart": "2.5px"}], "width": "45px", "height": "45px", "position": "absolute", "cornerRadius": "100px", "offsetStart": "3px", "offsetTop": "3px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": username, "size": "12px", "weight": "bold", "color": "#FFFFFF"}], "width": "110px", "height": "17.5px", "position": "absolute", "offsetEnd": "50px", "offsetTop": "13px", "justifyContent": "center", "alignItems": "center"}], "paddingAll": "0px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": textnya, "color": "#fefdfa", "size": "12px", "wrap": True}], "paddingAll": "4px", "backgroundColor": "#191919", "cornerRadius": "0px"}], "paddingTop": "1px","paddingBottom": "2.5px","paddingStart": "2px","paddingEnd": "2px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://i.ibb.co/0GfCjm7/20220520-223702.png", "aspectMode": "cover", "aspectRatio": "9:2", "size": "full", "animated": True}, {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/vDq3JS1/putar1.png","size": "full","aspectMode": "cover","animated": True},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/nMm1gBW/Moris-Brand.png", "size": "full","aspectMode": "cover","animated": True}],"position": "absolute","width": "40px","height": "40px","offsetBottom": "3px","offsetEnd": "2.5px","cornerRadius": "100px"}],"width": "45px","height": "45px","position": "absolute","offsetBottom": "2px","offsetEnd": "1.5px","cornerRadius": "100px","backgroundColor": "#000000"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "M O R I S  B O T S", "size": "12px", "align": "center", "color": "#e6c619", "weight": "bold"}], "position": "absolute", "height": "20px", "width": "120px", "justifyContent": "center", "offsetBottom": "14px", "offsetStart": "45px"}], "paddingAll": "0px"}], "paddingAll": "0px"} }
        return data

    def kaleraLine2(self, settings, inihari, textnya):
        data = {"type": "carousel","contents": [{"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://cdn.discordapp.com/attachments/296154578947407872/813975873811775559/black.jpg","size": "full","aspectRatio": "720:112"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": '{}'.format(settings["footerlabel"]),"size": "md","weight": "bold","color": "#FFFFFFFF"}],"position": "absolute","width": "168px","offsetStart": "35px","offsetTop": "13px"}],"paddingAll": "0px","action": {"type": "uri","label": "action","uri": "https://line.me/R/nv/chat"},"backgroundColor": "#1a1a1a"},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TODAY","size": "xxs","offsetEnd": "0px","align": "center","color": "#FFFFFF"}],"cornerRadius": "20px","backgroundColor": "#161616","width": "45px","position": "relative","offsetStart": "117px","paddingBottom": "2px","offsetTop": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": textnya,"size": "xs","wrap": True,"color": "#FFFFFF"}],"backgroundColor": "#272727","cornerRadius": "10px","width": "200px","offsetStart": "88px","offsetBottom": "0px","offsetTop": "10px","paddingAll": "5px"},{"type": "box","layout": "baseline","contents": [{"type": "text","text": inihari.strftime('%H:%M'),"margin": "md","size": "xxs","align": "start","offsetStart": "50px","contents": [],"position": "absolute"}],"width": "100px","height": "20px","justifyContent": "flex-end","offsetStart": "8px","offsetBottom": "3px"}],"backgroundColor": "#000000","paddingAll": "3px","paddingEnd": "xxl"},"footer": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://cdn.discordapp.com/attachments/296154578947407872/813980003225436180/AS.jpg","aspectRatio": "720:114","size": "full","aspectMode": "cover"}],"action": {"type": "uri","label": "action","uri": "https://line.me/ti/p/~{}".format(settings["idline"])},"paddingAll": "0px"},"styles": {"header": {"backgroundColor": "#1a1a1a"}}}]}
        return data

    def kaleraIG1(self, settings, inihari, hr, textnya):
        data = {"type": "carousel","contents": [{"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://cdn.discordapp.com/attachments/296154578947407872/813705536838565928/iganjay.jpg","aspectRatio": "678:103","size": "full","aspectMode": "fit","offsetBottom": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(settings["footerpict"]),"size": "full","aspectMode": "cover","action": {"type": "uri","label": "action","uri": "https://line.me/ti/p/~{}".format(settings["idline"])}}],"width": "25px","height": "25px","position": "absolute","cornerRadius": "100px","offsetStart": "43px","offsetTop": "12px","backgroundColor": "#000000"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(settings["footerlabel"]),"color": "#ffffff","size": "sm","weight": "bold"}],"position": "absolute","backgroundColor": "#ffffff00","offsetTop": "16px","offsetStart": "75px","width": "110px"}],"paddingAll": "0px","borderColor": "#000000","action": {"type": "uri","label": "action","uri": "https://line.me/R/nv/chat"}},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(inihari.strftime(hr+' %H:%M')),"color": "#FFFFFF","weight": "bold","size": "xxs","align": "center","offsetEnd": "10px"}]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": textnya,"wrap": True,"size": "xs","color": "#FFFFFF"}],"backgroundColor": "#262626","paddingAll": "5px","cornerRadius": "10px","width": "200px","offsetStart": "88px","offsetBottom": "0px","offsetTop": "2px"}],"backgroundColor": "#000000","paddingAll": "3px"},"footer": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://cdn.discordapp.com/attachments/296154578947407872/813721100185108530/asfsag.jpg","aspectRatio": "720:126","size": "full"}],"paddingAll": "2px","backgroundColor": "#000000","action": {"type": "uri","label": "action","uri": "https://line.me/ti/p/~{}".format(settings["idline"])}},"styles": {"header": {"backgroundColor": "#000000"}}}]}
        return data

    def kaleraIG2(self, settings, inihari, hr, textnya):
        data = {"type": "carousel","contents": [{"type": "bubble","header": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://cdn.discordapp.com/attachments/296154578947407872/813945651598852106/temp.jpg","size": "full","aspectRatio": "678:100"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(settings["footerlabel"]),"size": "md","weight": "bold"}],"position": "absolute","width": "110px","offsetStart": "71px","offsetTop": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(settings["footerpict"]),"size": "full","aspectMode": "cover","action": {"type": "uri","label": "action","uri": "https://line.me/ti/p/~{}".format(settings["idline"])}}],"width": "25px","height": "25px","offsetStart": "43px","cornerRadius": "100px","offsetTop": "12px","paddingAll": "0px","position": "absolute"}],"paddingAll": "0px","action": {"type": "uri","label": "action","uri": "https://line.me/R/nv/chat"}},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(inihari.strftime(hr+' %H:%M')),"weight": "bold","size": "xxs","align": "center","offsetEnd": "10px"}]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": textnya,"size": "xs","wrap": True}],"backgroundColor": "#EFEFEF","paddingAll": "5px","cornerRadius": "10px","width": "200px","offsetStart": "88px","offsetTop": "2px","offsetBottom": "0px"}],"backgroundColor": "#FFFFFF","paddingAll": "3px"},"footer": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://cdn.discordapp.com/attachments/296154578947407872/813951421825286174/198249.jpg","aspectRatio": "710:126","size": "full"}],"paddingAll": "2px","action": {"type": "uri","label": "action","uri": "https://line.me/ti/p/~{}".format(settings["idline"])}}}]}
        return data

    def kaleraON(self, settings, textnya):
        data = {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": settings["footerpict"],"aspectMode": "cover","size": "full","position": "absolute"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/4NvFJxH/kalera-on.png","animated": True,"size": "md"}],"height": "50px","justifyContent": "center","width": "90px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": textnya,"color": "#FFFFFF","size": "sm","weight": "bold"}],"alignItems": "center","margin": "md"}],"alignItems": "center","backgroundColor": f"{settings['colorlabel']}bb","cornerRadius": "6px","paddingStart": "2%","paddingEnd": "2%"}],"paddingAll": "2%","backgroundColor": "#000000aa"}],"paddingAll": "0%"}}
        return data

    def kaleraOFF(self, settings, textnya):
        data = {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": settings["footerpict"],"aspectMode": "cover","size": "full","position": "absolute"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/X255xdv/kalera-off.png","animated": True,"size": "md"}],"height": "50px","justifyContent": "center","width": "90px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": textnya,"color": "#FFFFFF","size": "sm","weight": "bold"}],"alignItems": "center","margin": "md"}],"alignItems": "center","backgroundColor": f"{settings['colorlabel']}bb","cornerRadius": "6px","paddingStart": "2%","paddingEnd": "2%"}],"paddingAll": "2%","backgroundColor": "#000000aa"}],"paddingAll": "0%"}}
        return data

    def kaleraCorona(self, case1, rip1, fit1, case2, rip2, fit2): 
        data = {"type": "bubble", "size": "micro", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "COVID-19", "size": "sm", "weight": "bold", "contents": [{"type": "span", "text": "INFO "}, {"type": "span", "text": "COVID-19", "color": "#ff0000"} ] }, {"type": "separator", "margin": "sm"}, {"type": "text", "text": "WORLD", "size": "xxs", "weight": "bold", "margin": "sm", "align": "center"}, {"type": "separator", "margin": "sm"} ], "paddingAll": "10px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "Case", "size": "xxs"}, {"type": "text", "text": case1, "size": "xxs", "color": "#ffba00", "flex": 2} ], "paddingStart": "10px", "paddingEnd": "10px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "RIP", "size": "xxs"}, {"type": "text", "text": rip1, "size": "xxs", "color": "#ff0000", "flex": 2} ], "paddingStart": "10px", "paddingEnd": "10px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "FIT", "size": "xxs"}, {"type": "text", "text": fit1, "size": "xxs", "color": "#13ca06", "flex": 2} ], "paddingStart": "10px", "paddingEnd": "10px"} ], "paddingBottom": "5px", "paddingStart": "5px", "paddingEnd": "5px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "separator", "margin": "sm"}, {"type": "text", "text": "INDONESIA", "size": "xxs", "weight": "bold", "margin": "sm", "align": "center"}, {"type": "separator", "margin": "sm"} ], "paddingTop": "0px", "paddingBottom": "5px", "paddingAll": "10px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "Case", "size": "xxs"}, {"type": "text", "text": case2, "size": "xxs", "color": "#ffba00", "flex": 2} ], "paddingStart": "10px", "paddingEnd": "10px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "RIP", "size": "xxs"}, {"type": "text", "text": rip2, "size": "xxs", "color": "#ff0000", "flex": 2} ], "paddingStart": "10px", "paddingEnd": "10px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "FIT", "size": "xxs"}, {"type": "text", "text": fit2, "size": "xxs", "color": "#13ca06", "flex": 2} ], "paddingStart": "10px", "paddingEnd": "10px"} ], "paddingBottom": "10px", "paddingStart": "5px", "paddingEnd": "5px"} ], "paddingAll": "0px"} }
        return data

    def kaleraYtb(self, author, duration, thumbnail, title, watched):
        data = {"type": "bubble", "size": "kilo", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": thumbnail, "aspectRatio": "2:1", "aspectMode": "cover", "size": "full"}, {"type": "box", "layout": "vertical", "contents": [{'type':'image','url':"https://api.imjustgood.com/img/Ayr0Vfd9bz.jpg",'size':'xxs'} ], "position": "absolute", "backgroundColor": "#000000", "paddingAll": "5px"} ], "flex": 0 }, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": title, "weight": "bold", "wrap": True, "decoration": "underline", "size": "xs"} ], "paddingTop": "5px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Author", "size": "xs"}, {"type": "text", "text": "Duration", "size": "xs"}, {"type": "text", "text": "Watched", "size": "xs"} ], "paddingEnd": "10px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": author, "size": "xs"}, {"type": "text", "text": duration, "size": "xs"}, {"type": "text", "text": f"{watched}", "size": "xs"} ], "paddingEnd": "15px", "flex": 2 } ], "backgroundColor": "#ffffff", "paddingTop": "5px"} ], "paddingAll": "10px", "cornerRadius": "10px"} }
        return data

    def kaleraTiktok(self, profile_pic, nickname, likes, followers, following, username):
        data = {"type": "flex", "altText": nickname, "contents": {"type": "carousel", "contents": [{"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/tH592Fz/ACODE-TIKTOK-TOP.png","size": "full","aspectRatio": "1280:186"}]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": nickname,"size": "sm","color": "#000000","weight": "bold"}],"position": "absolute","alignItems": "center","offsetStart": "23%","offsetTop": "25%","width": "140px"}]},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": profile_pic,"size": "full","aspectMode": "cover","action": {"type": "uri","uri": profile_pic}}],"width": "60px","height": "60px","cornerRadius": "100px"}],"justifyContent": "center"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": username,"size": "xs","color": "#000000","weight": "bold"}],"alignItems": "center","margin": "lg"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": following,"size": "sm","weight": "bold"},{"type": "text","text": "Following","size": "xxs"}],"alignItems": "center"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": followers,"size": "sm","weight": "bold"},{"type": "text","text": "Followers","size": "xxs"}],"alignItems": "center"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": likes,"size": "sm","weight": "bold"},{"type": "text","text": "Likes","size": "xxs"}],"alignItems": "center"}],"margin": "lg"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Follow","size": "sm","weight": "bold","color": "#FFFFFF","action": {"type": "uri","uri": f"https://www.tiktok.com/{username}"}}],"backgroundColor": "#FE2C55","width": "100px","alignItems": "center","height": "30px","justifyContent": "center"}],"alignItems": "center","margin": "lg"},{"type": "box","layout": "vertical","contents": [],"height": "30px"}],"paddingAll": "0%"}}]}}
        return data

    def kaleraTwitter(self, profile_pic, fullname, bio, followers, following, link, banner):
        data = {"type": "flex", "altText": fullname, "contents": {"type": "carousel", "contents": [{"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": banner,"size": "full","aspectRatio": "460:163","aspectMode": "cover","action": {"type": "uri","uri": banner}}]},{"type": "box","layout": "vertical","contents": [{"type": "image","url": profile_pic,"aspectMode": "cover","action": {"type": "uri","uri": profile_pic}}],"position": "absolute","offsetTop": "23%","offsetStart": "5%","cornerRadius": "100px","width": "70px","height": "70px","borderWidth": "medium","borderColor": "#000000"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Follow","color": "#000000","weight": "bold","action": {"type": "uri","uri": f"https://www.twitter.com/{link}"}}],"backgroundColor": "#FFFFFF","cornerRadius": "20px","width": "95px","height": "35px","justifyContent": "center","alignItems": "center"}],"alignItems": "flex-end","paddingAll": "3%"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": fullname,"size": "md","color": "#FFFFFF","weight": "bold"},{"type": "text","text": link,"size": "xs","color": "#FFFFFF"}],"paddingStart": "5%","paddingEnd": "5%"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": bio,"color": "#FFFFFF","wrap": True,"size": "xxs"}],"paddingStart": "5%","paddingEnd": "5%","margin": "md"},{"type": "box","layout": "horizontal","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": following,"size": "xs","color": "#FFFFFF","weight": "bold"}],"width": "45px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Following","color": "#FFFFFF","size": "xs"}]},{"type": "box","layout": "vertical","contents": [{"type": "text","text": followers,"size": "xs","color": "#FFFFFF","weight": "bold"}],"width": "45px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Followers","color": "#FFFFFF","size": "xs"}]}],"paddingStart": "5%","paddingEnd": "5%","paddingBottom": "5%","margin": "md"}],"paddingAll": "0%","backgroundColor": "#182226"}}]}}
        return data

    def kaleraGithub(self, fullname, biography, repo, followers, following, avatar):
        data = {"type": "flex", "altText": fullname, "contents": {"type": "carousel", "contents": [{"type": "bubble", "size": "kilo", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "GitHub", "size": "lg", "weight": "bold", "color": "#ffffffdd"} ], "paddingBottom": "5px"}, {"type": "separator"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": avatar, "aspectRatio": "1:1", "aspectMode": "cover", "align": "start", "action": {"type": "uri", "uri": avatar }, "size": "sm"} ], "paddingAll": "10px", "flex": 0, "paddingStart": "0px", "paddingBottom": "8px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": fullname, "weight": "bold", "color": "#ffffffdd"}, {"type": "text", "text": "JUSTGOOD", "size": "xxs", "margin": "sm", "contents": [{"type": "span", "text": f"{followers} "}, {"type": "span", "text": "Followers", "weight": "bold", "color": "#ffffffdd"} ], "color": "#ffffffaa"}, {"type": "text", "text": "JUSTGOOD", "size": "xxs", "margin": "sm", "contents": [{"type": "span", "text": f"{following} "}, {"type": "span", "text": "Following", "weight": "bold", "color": "#ffffffdd"} ], "color": "#ffffffaa"}, {"type": "text", "text": "JUSTGOOD", "size": "xxs", "contents": [{"type": "span", "text": f"{repo} "}, {"type": "span", "text": "Repositories", "weight": "bold", "color": "#ffffffdd"} ], "margin": "sm", "color": "#ffffffaa"} ], "paddingAll": "10px", "paddingStart": "0px", "paddingTop": "8px"} ] }, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": f"{biography} ", "size": "xxs", "color": "#ffffffdd", "wrap": True, "style": "italic"} ], "paddingTop": "0px", "paddingAll": "10px", "paddingStart": "0px"} ], "paddingAll": "10px", "paddingStart": "15px", "paddingEnd": "15px", "paddingBottom": "10px"}, "styles": {"body": {"backgroundColor": "#0d1117"} },'action':{'type':'uri','label':'action','uri':'https://github.com/'+fullname}}]}}
        return data

    def kaleraPorn(self, pict, title, duration, quality, watched, vids):
        data = {"type": "flex", "altText": title, "contents": {"type": "carousel", "contents": [{"type": "bubble", "size": "kilo", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": pict, "aspectRatio": "2:1.3", "aspectMode": "cover", "action": {"type": "uri", "uri": pict }, "size": "full"} ] }, {"type": "box", "layout": "vertical", "contents": [{'type':'image','url':"https://i.ibb.co/qCW4gsG/Imjustgood.jpg",'size':'xxs'} ], "position": "absolute", "backgroundColor": "#212121", "paddingAll": "5px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": title, "weight": "bold", "color": "#ffffffcc", "maxLines": 2, "wrap": True, "decoration": "underline"} ], "paddingTop": "10px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "Duration", "size": "xs", "color": "#ffffffcc", "weight": "bold"}, {"type": "text", "text": duration, "size": "xs", "color": "#ffffffcc", "flex": 2 } ], "paddingTop": "5px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "Quality", "size": "xs", "color": "#ffffffcc", "weight": "bold"}, {"type": "text", "text": quality, "size": "xs", "color": "#ffffffcc", "flex": 2 } ] }, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "Watched", "size": "xs", "color": "#ffffffcc", "weight": "bold"}, {"type": "text", "text": watched, "size": "xs", "color": "#ffffffcc", "flex": 2 } ] }, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "PLAY", "color": "#ffffffcc", "decoration": "underline", "weight": "bold"} ], "position": "absolute", "offsetEnd": "10px", "background": {"type": "linearGradient", "angle": "30deg", "startColor": "#900000", "endColor": "#ff0000", "centerColor": "#900000"}, "paddingAll": "12px", "offsetBottom": "10px", "cornerRadius": "10px", "action": {"type": "uri", "uri": vids } } ], "paddingAll": "10px"}, "styles": {"body": {"backgroundColor": "#212121"} } }]}}
        return data

    def kaleraJoox(self, artist, duration, thumbnail, title):
        data = {"type": "flex", "altText": title, "contents": {"type": "carousel", "contents": [{"type": "bubble", "size": "kilo", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": thumbnail, "aspectRatio": "1:1", "aspectMode": "cover", "align": "start"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "JOOX", "weight": "bold", "color": "#28a745", "size": "xxs"} ], "position": "absolute", "backgroundColor": "#141414", "paddingAll": "5px"} ], "flex": 0 }, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": title, "color": "#ffffff", "weight": "bold", "wrap": True, "maxLines": 2 }, {"type": "text", "text": artist, "size": "xs", "color": "#ffffff"}, {"type": "text", "text": duration, "size": "xs", "color": "#ffffff"} ], "paddingEnd": "10px", "paddingStart": "10px", "justifyContent": "center"} ] } ], "paddingAll": "10px", "cornerRadius": "10px"}, "styles": {"body": {"backgroundColor": "#141414"} } }]}}
        return data

    def kaleraAdzan(self, waktu, city, imsyak, subuh, terbit, dhuha, dzuhur, ashar, maghrib, isya):
        data = {"type": "flex", "altText": "Jadwal Adzan {}".format(city), "contents": {"type": "carousel", "contents": [{"type": "bubble", "size": "kilo", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": "https://api.imjustgood.com/img/masjid.jpg", "aspectRatio": "2:1.3", "aspectMode": "cover", "size": "full"} ] }, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": waktu, "color": "#ffffff", "size": "sm"} ], "position": "absolute", "offsetTop": "10px", "offsetEnd": "10px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": city, "color": "#ffffff", "size": "sm", "wrap": True, "maxLines": 2 } ], "position": "absolute", "offsetTop": "10px", "offsetStart": "10px", "width": "100px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Imsyak", "size": "sm"} ], "paddingAll": "5px", "backgroundColor": "#00000022", "paddingStart": "15px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": imsyak, "size": "sm", "align": "center"} ], "paddingAll": "5px"} ] }, {"type": "separator", "color": "#00000055"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Subuh", "size": "sm"} ], "paddingAll": "5px", "backgroundColor": "#00000022", "paddingStart": "15px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": subuh, "size": "sm", "align": "center"} ], "paddingAll": "5px"} ] }, {"type": "separator", "color": "#00000055"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Terbit", "size": "sm"} ], "paddingAll": "5px", "backgroundColor": "#00000022", "paddingStart": "15px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": terbit, "size": "sm", "align": "center"} ], "paddingAll": "5px"} ] }, {"type": "separator", "color": "#00000055"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Dhuha", "size": "sm"} ], "paddingAll": "5px", "backgroundColor": "#00000022", "paddingStart": "15px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": dhuha, "size": "sm", "align": "center"} ], "paddingAll": "5px"} ] }, {"type": "separator", "color": "#00000055"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Dzuhur", "size": "sm"} ], "paddingAll": "5px", "backgroundColor": "#00000022", "paddingStart": "15px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": dzuhur, "size": "sm", "align": "center"} ], "paddingAll": "5px"} ] }, {"type": "separator", "color": "#00000055"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Ashar", "size": "sm"} ], "paddingAll": "5px", "backgroundColor": "#00000022", "paddingStart": "15px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": ashar, "size": "sm", "align": "center"} ], "paddingAll": "5px"} ] }, {"type": "separator", "color": "#00000055"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Maghrib", "size": "sm"} ], "paddingAll": "5px", "backgroundColor": "#00000022", "paddingStart": "15px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": maghrib, "size": "sm", "align": "center"} ], "paddingAll": "5px"} ] }, {"type": "separator", "color": "#00000055"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "Isya", "size": "sm"} ], "paddingAll": "5px", "backgroundColor": "#00000022", "paddingStart": "15px", "justifyContent": "center", "paddingBottom": "7px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": isya, "size": "sm", "align": "center"} ], "paddingAll": "5px"} ] } ], "paddingAll": "0px"} }]}}
        return data

    def kaleraZodiac(self, dateRange, sign, imageUrl, desc):
        data = {"type": "flex", "altText": "Zodiac {}".format(sign.upper()), "contents": {"type": "carousel", "contents": [{"type": "bubble", "size": "kilo", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": "ZODIAC", "weight": "bold", "size": "xxs"} ], "position": "absolute", "offsetTop": "15px", "offsetStart": "15px", "borderWidth": "1px", "borderColor": "#000000cc", "cornerRadius": "50px", "paddingStart": "7px", "paddingEnd": "7px", "paddingTop": "2px", "paddingBottom": "2px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": imageUrl, "aspectRatio": "1:1", "aspectMode": "cover", "action": {"type": "uri", "uri": imageUrl } } ], "cornerRadius": "100px"} ], "alignItems": "center", "paddingTop": "20px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": sign.upper(), "weight": "bold"}, {"type": "text", "text": dateRange, "size": "xs"} ], "alignItems": "center", "paddingTop": "10px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": desc, "size": "xxs", "wrap": True } ], "paddingTop": "15px", "paddingBottom": "5px"} ], "paddingAll": "10px", "paddingStart": "15px", "paddingEnd": "15px", "paddingBottom": "10px"} }]}}
        return data

    def kaleraCuaca(self, place, weather, temperature, humidity, wind):
        data = {"type": "flex", "altText": "Cuaca {}".format(place), "contents": {"type": "carousel", "contents": [{"type": "bubble", "size": "micro", "body": {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "text", "text": place, "size": "sm", "weight": "bold", "wrap": True }, {"type": "separator", "margin": "sm"}, {"type": "text", "text": weather, "size": "xxs", "weight": "bold", "wrap": True, "margin": "sm", "align": "center"}, {"type": "separator", "margin": "sm"} ], "paddingAll": "10px", "paddingTop": "5px", "paddingBottom": "5px"}, {"type": "box", "layout": "vertical", "contents": [{"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "Temperature", "size": "xxs"}, {"type": "text", "text": temperature, "size": "xxs", "align": "center"} ], "paddingStart": "10px", "paddingEnd": "10px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "Humidity", "size": "xxs"}, {"type": "text", "text": humidity, "size": "xxs", "align": "center"} ], "paddingStart": "10px", "paddingEnd": "10px"}, {"type": "box", "layout": "horizontal", "contents": [{"type": "text", "text": "Wind Speed", "size": "xxs"}, {"type": "text", "text": wind, "size": "xxs", "align": "center"} ], "paddingStart": "10px", "paddingEnd": "10px"} ], "paddingBottom": "8px", "paddingStart": "5px", "paddingEnd": "5px"} ], "paddingAll": "0px"} }]}}
        return data

    def kaleraFaketweet(self, pict, name, textnya):
        data = {"type":"flex","altText":"𝙆𝘼𝙇𝙀𝙍𝘼 𝙏𝙀𝘼𝙈","contents":{"body": {"contents": [{"contents": [{"aspectMode": "cover","aspectRatio": "5:1","size": "full","type": "image","url": "https://imagizer.imageshack.com/img923/1734/iz9aRh.png"}],"layout": "vertical","type": "box"},{"contents": [{"aspectMode": "cover","aspectRatio": "1:1","size": "xs","type": "image","url": pict}],"cornerRadius": "100px","layout": "vertical","offsetStart": "15px","offsetTop": "13px","position": "absolute","type": "box"},{"contents": [{"color": "#FFFFFF","size": "xs","text": "{}".format(name),"type": "text","weight": "bold"},{"color": "#84929b","size": "xs","text": "@{}".format(name),"type": "text"}],"layout": "vertical","offsetStart": "87px","offsetTop": "23px","position": "absolute","type": "box"},{"contents": [{"color": "#FFFFFF","size": "xl","text": "{}".format(textnya),"type": "text","wrap": True}],"layout": "vertical","paddingBottom": "10px","paddingEnd": "15px","paddingStart": "15px","paddingTop": "22px","type": "box"},{"contents": [{"aspectMode": "cover","aspectRatio": "5:1","size": "full","type": "image","url": "https://imagizer.imageshack.com/img924/1714/K1ABpF.png"}],"layout": "vertical","offsetStart": "5px","type": "box"}],"layout": "vertical","paddingAll": "0px","type": "box"},"styles": {"body": {"backgroundColor": "#0f2028"}},"type": "bubble"},"type": "flex"}	
        return data

    def kaleraFakeline(self, pict, name, textnya):
        data = {"type":"flex","altText":"𝙆𝘼𝙇𝙀𝙍𝘼 𝙏𝙀𝘼𝙈","contents":{"body": {"contents": [{"contents": [{"aspectMode": "cover","aspectRatio": "8.05:1.07","size": "full","type": "image","url": "https://imagizer.imageshack.com/img923/5751/TvzZa1.png"}],"layout": "vertical","offsetStart": "-10px","offsetTop": "6px","type": "box"},{"contents": [{"color": "#000000","size": "xs","text": "{}".format(textnya),"type": "text","wrap": True}],"layout": "vertical","paddingBottom": "2px","paddingEnd": "20px","paddingStart": "17.7px","paddingTop": "8px","type": "box"},{"contents": [{"aspectMode": "cover","aspectRatio": "4.83:1.09","size": "full","type": "image","url": "https://imagizer.imageshack.com/img923/4999/R2sfQ1.png"}],"layout": "vertical","offsetStart": "6px","type": "box"},{"contents": [{"aspectMode": "cover","aspectRatio": "1:1","size": "xxs","type": "image","url": pict}],"cornerRadius": "100px","layout": "vertical","offsetStart": "12px","offsetTop": "10px","position": "absolute","type": "box","width": "28px"},{"contents": [{"color": "#000000","size": "xs","text": "{}".format(name),"type": "text","weight": "bold"}],"layout": "vertical","offsetStart": "45px","offsetTop": "16.3px","position": "absolute","type": "box","width": "150px"}],"layout": "vertical","paddingAll": "0px","type": "box"},"type": "bubble"},"type": "flex"}
        return data

    def kaleraFakefb(self, pict, name, textnya):
        data = {"type":"flex","altText":"𝙆𝘼𝙇𝙀𝙍𝘼 𝙏𝙀𝘼𝙈","contents":{"body": {"contents": [{"contents": [{"aspectMode": "cover","aspectRatio": "7.81:1.24","size": "full","type": "image","url": "https://imagizer.imageshack.com/img921/2204/x4H0ez.png"}],"layout": "vertical","offsetStart": "-4.5px","offsetTop": "-3px","type": "box"},{"contents": [{"color": "#000000","size": "md","text": "{}".format(textnya),"type": "text","wrap": True}],"layout": "vertical","paddingEnd": "11px","paddingStart": "11px","paddingTop": "1px","type": "box"},{"contents": [{"aspectMode": "cover","aspectRatio": "7.81:1.47","size": "full","type": "image","url": "https://imagizer.imageshack.com/img921/6507/37bVUA.png"}],"layout": "vertical","type": "box"},{"contents": [{"aspectMode": "cover","aspectRatio": "1:1","size": "xxs","type": "image","url": pict}],"layout": "vertical","offsetStart": "12px","offsetTop": "14.5px","position": "absolute","type": "box","width": "28px"},{"contents": [{"color": "#4e5669","size": "xxs","text": "{}".format(name),"type": "text","weight": "bold"}],"layout": "vertical","offsetStart": "45px","offsetTop": "17px","position": "absolute","type": "box","width": "120px"}],"layout": "vertical","paddingAll": "0px","type": "box"},"type": "bubble"},"type": "flex"}
        return data

    def kaleraFakefb(self, pict, name, textnya):
        data = {"type":"flex","altText":"𝙆𝘼𝙇𝙀𝙍𝘼 𝙏𝙀𝘼𝙈","contents":{"body": {"contents": [{"contents": [{"aspectMode": "cover","aspectRatio": "7.81:1.24","size": "full","type": "image","url": "https://imagizer.imageshack.com/img921/2204/x4H0ez.png"}],"layout": "vertical","offsetStart": "-4.5px","offsetTop": "-3px","type": "box"},{"contents": [{"color": "#000000","size": "md","text": "{}".format(textnya),"type": "text","wrap": True}],"layout": "vertical","paddingEnd": "11px","paddingStart": "11px","paddingTop": "1px","type": "box"},{"contents": [{"aspectMode": "cover","aspectRatio": "7.81:1.47","size": "full","type": "image","url": "https://imagizer.imageshack.com/img921/6507/37bVUA.png"}],"layout": "vertical","type": "box"},{"contents": [{"aspectMode": "cover","aspectRatio": "1:1","size": "xxs","type": "image","url": pict}],"layout": "vertical","offsetStart": "12px","offsetTop": "14.5px","position": "absolute","type": "box","width": "28px"},{"contents": [{"color": "#4e5669","size": "xxs","text": "{}".format(name),"type": "text","weight": "bold"}],"layout": "vertical","offsetStart": "45px","offsetTop": "17px","position": "absolute","type": "box","width": "120px"}],"layout": "vertical","paddingAll": "0px","type": "box"},"type": "bubble"},"type": "flex"}
        return data

    def kaleraSider(self, pict, pict2, name):
        data = {"type": "bubble", "size": "micro", "header": {"type": "box", "layout": "vertical", "contents": [{"type": "image","url": pict , "aspectRatio": "3:4", "aspectMode": "cover", "size": "full", "action": {"type": "uri", "label": "action","uri": "https://line.me/ti/p/~linux.1"} }, {"type": "box", "layout": "horizontal", "contents": [{"type": "box", "layout": "vertical", "contents": [{"type": "image", "url": pict2, "size": "15px", "aspectRatio": "1:1", "aspectMode": "cover"}], "width": "25px"}, { "type": "separator"}, { "type": "text", "text": name, "color": "#FFFFFF", "size": "xxs", "offsetStart": "10px"}], "position": "absolute", "offsetTop": "190px", "offsetBottom": "5px", "offsetStart": "5px", "cornerRadius": "50px", "backgroundColor": "#000000aa", "alignItems": "center", "justifyContent": "center", "width": "150px"}, {"type": "box","layout": "vertical","contents": [{"type": "image","url":"https://i.ibb.co/5KMcFSq/CCTV.png","animated": True,"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "25px","height": "25px","borderWidth": "0px","borderColor": "#808080","cornerRadius": "0px","offsetTop": "2px","offsetStart": "2px"}, {"type": "box","layout": "vertical","contents": [{"type": "image","url":"https://i.ibb.co/VNsTzTQ/emas.png","animated": True,"size": "full","aspectRatio": "3:4","aspectMode": "cover"}],"position": "absolute"}], "paddingAll": "0px"} }
        return data

    def yansblue(self, settings, userpict, username, textnya):
        data = {
      "type": "bubble",
      "size": "kilo",
      "header": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/j33ksC0/kebyar.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:3",
            "position": "absolute",
            "animated": True
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/j33ksC0/kebyar.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:3",
            "offsetTop": "480.2px",
            "position": "absolute",
            "animated": True
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/j33ksC0/kebyar.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:3",
            "offsetTop": "880.2px",
            "position": "absolute",
            "animated": True
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/DKnsKCb/TOP-FLEX-CLUTAXS.png",
            "size": "full",
            "aspectRatio": "10:1.800",
            "aspectMode": "cover"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/4VBdD5d/TOP-ALL-CLUTAXS.png",
            "size": "full",
            "aspectRatio": "10:1.800",
            "aspectMode": "cover",
            "animated": True,
            "position": "absolute"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": userpict,
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "40px",
            "height": "40px",
            "cornerRadius": "100px",
            "backgroundColor": "#870000",
            "borderWidth": "2px",
            "offsetTop": "1.5px",
            "offsetStart": "1px",
            "borderColor": "#191919"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": username,
                "size": "7.5px",
                "weight": "bold",
                "color": "#FFFFFF",
                "align": "center"
              }
            ],
            "width": "110px",
            "height": "15px",
            "position": "absolute",
            "offsetEnd": "105px",
            "offsetTop": "22.5px",
            "offsetStart": "142.5px",
            "justifyContent": "center"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": textnya,
                            "size": "xxs",
                            "color": "#f5f5f5",
                            "offsetStart": "0px",
                            "wrap": True
                          }
                        ],
                        "justifyContent": "center"
                      }
                    ]
                  }
                ],
                "paddingAll": "5px",
                "backgroundColor": "#08273b"
              }
            ],
            "paddingTop": "2px",
            "paddingBottom": "2px",
            "paddingStart": "3px",
            "paddingEnd": "3px"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/ZWNRf76/flexbawah.png",
            "size": "full",
            "aspectRatio": "100:9.100",
            "aspectMode": "cover",
            "animated": True
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/0jVC9QX/RESPONSE-MSG-CLUTAXS.png",
            "size": "full",
            "aspectRatio": "100:12.5",
            "aspectMode": "cover",
            "position": "absolute",
            "offsetBottom": "0px",
            "animated": True
          }
        ],
        "paddingAll": "0px"
      }
    }
        return data

    def media_fakecall(self,picture,picture2,nama,nama2,cover):
        data = {
          "type": "bubble",
          "size": "kilo",
          "footer": {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": cover,
                "size": "full",
                "aspectMode": "cover",
                "position": "absolute",
                "aspectRatio": "5:10"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://i.ibb.co/bWsd8g2/5e7120aaef10.png",
                            "aspectRatio": "1:1",
                            "size": "full"
                          }
                        ],
                        "height": "135px",
                        "width": "135px",
                        "offsetBottom": "50px",
                        "offsetStart": "10px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "2",
                            "color": "#D3D3D3",
                            "size": "8px"
                          }
                        ],
                        "offsetTop": "10px",
                        "width": "15px",
                        "height": "15px",
                        "offsetEnd": "19px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "00.01",
                            "size": "8px",
                            "color": "#D3D3D3"
                          }
                        ],
                        "width": "25px",
                        "height": "15px",
                        "offsetTop": "10px",
                        "offsetEnd": "25px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Leave",
                            "color": "#FFFFFF",
                            "size": "10px",
                            "align": "center",
                            "weight": "bold"
                          }
                        ],
                        "backgroundColor": "#DC143C",
                        "borderColor": "#DC143C",
                        "width": "65px",
                        "height": "20px",
                        "offsetTop": "5px",
                        "cornerRadius": "sm",
                        "borderWidth": "medium",
                        "offsetStart": "10px",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "https://line.me/ti/p/~linux.1"
                        }
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "image",
                            "url": picture,
                            "aspectRatio": "1:1",
                            "aspectMode": "cover"
                          }
                        ],
                        "width": "75px",
                        "height": "75px",
                        "cornerRadius": "50px",
                        "offsetTop": "120px",
                        "offsetEnd": "205px",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": picture
                        }
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": nama,
                            "color": "#D3D3D3",
                            "size": "12px",
                            "align": "center"
                          }
                        ],
                        "offsetEnd": "295px",
                        "offsetTop": "210px",
                        "height": "15px",
                        "width": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "image",
                            "url": picture2,
                            "aspectRatio": "1:1",
                            "aspectMode": "cover"
                          }
                        ],
                        "width": "75px",
                        "height": "75px",
                        "cornerRadius": "50px",
                        "offsetTop": "120px",
                        "offsetEnd": "270px",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": picture2
                        }
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": nama2,
                            "size": "12px",
                            "color": "#D3D3D3",
                            "align": "center"
                          }
                        ],
                        "width": "100px",
                        "height": "15px",
                        "offsetEnd": "360px",
                        "offsetTop": "210px"
                      }
                    ],
                    "height": "300px",
                    "backgroundColor": "#000000cc"
                  }
                ]
              },
              {
                "type": "separator",
                "color": "#D3D3D3"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/44ysyXY/7f4a1764a4c1.png"
                      }
                    ],
                    "width": "55px",
                    "height": "80px",
                    "offsetBottom": "15px",
                    "offsetStart": "100px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/Yd0bb8V/586ce541e145.png",
                        "aspectRatio": "1:1",
                        "size": "full"
                      }
                    ],
                    "offsetBottom": "80px",
                    "width": "220px",
                    "height": "150px",
                    "offsetStart": "15px"
                  }
                ],
                "paddingAll": "3px",
                "height": "100px",
                "backgroundColor": "#000000cc"
              }
            ],
            "paddingAll": "0px"
          }
        }
        return data

    def kalerastartcall(self, pict, name, name2, nows):
        data = {
          "type": "bubble",
          "size": "kilo",
          "header": {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": pict,
                    "size": "full",
                    "aspectMode": "cover"
                  }
                ],
                "height": "75px",
                "cornerRadius": "100px",
                "borderWidth": "3px",
                "borderColor": "#505050",
                "width": "75px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://www.linkpicture.com/q/klr-start-call.png",
                    "size": "full",
                    "aspectMode": "cover",
                    "aspectRatio": "1:1",
                    "animated": True
                  }
                ],
                "height": "30px",
                "cornerRadius": "100px",
                "borderWidth": "3px",
                "borderColor": "#505050",
                "width": "30px",
                "position": "absolute",
                "offsetBottom": "10px",
                "offsetStart": "10px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "START CALL GROUP",
                    "size": "12px",
                    "weight": "bold",
                    "color": "#00ff0090"
                  },
                  {
                    "type": "text",
                    "text": "\n",
                    "size": "4px",
                    "color": "#ffffff"
                  },
                  {
                    "type": "text",
                    "text": "• Host: {}".format(name),
                    "size": "11px",
                    "color": "#ffffff"
                  },
                  {
                    "type": "text",
                    "text": "• Group: {}".format(name2), 
                    "size": "11px",
                    "color": "#ffffff"
                  },
                  {
                    "type": "text",
                    "text": "• Started: {}".format(nows),
                    "size": "11px",
                    "color": "#ffffff"
                  },
                  {
                    "type": "separator",
                    "margin": "5px",
                    "color": "#000000"
                  }
                ],
                "position": "absolute",
                "offsetTop": "15px",
                "offsetBottom": "15px",
                "offsetEnd": "15px",
                "offsetStart": "100px",
                "paddingAll": "5px",
                "cornerRadius": "4px",
                "backgroundColor": "#505050",
                "justifyContent": "center"
              }
            ],
            "paddingAll": "15px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://line.me/ti/p/~linux.1"
            }
          },
          "styles": {
            "header": {
              "backgroundColor": "#000000"
            }
          }
        }
        return data

    def kaleraendcall(self, pict, name, name2, nows):
        data = {
          "type": "bubble",
          "size": "kilo",
          "header": {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": pict,
                    "size": "full",
                    "aspectMode": "cover"
                  }
                ],
                "height": "75px",
                "cornerRadius": "100px",
                "borderWidth": "3px",
                "borderColor": "#505050",
                "width": "75px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://www.linkpicture.com/q/klr-end-call.png",
                    "size": "full",
                    "aspectMode": "cover",
                    "aspectRatio": "1:1",
                    "animated": True
                  }
                ],
                "height": "30px",
                "cornerRadius": "100px",
                "borderWidth": "3px",
                "borderColor": "#505050",
                "width": "30px",
                "position": "absolute",
                "offsetBottom": "10px",
                "offsetStart": "10px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "ENDED GROUP CALL",
                    "size": "12px",
                    "weight": "bold",
                    "color": "#FF000090"
                  },
                  {
                    "type": "text",
                    "text": "\n",
                    "size": "4px",
                    "color": "#ffffff"
                  },
                  {
                    "type": "text",
                    "text": "• Host: {}".format(name),
                    "size": "11px",
                    "color": "#ffffff"
                  },
                  {
                    "type": "text",
                    "text": "• Group: {}".format(name2), 
                    "size": "11px",
                    "color": "#ffffff"
                  },
                  {
                    "type": "text",
                    "text": "• Duration: {}".format(nows),
                    "size": "11px",
                    "color": "#ffffff"
                  },
                  {
                    "type": "separator",
                    "margin": "5px",
                    "color": "#000000"
                  }
                ],
                "position": "absolute",
                "offsetTop": "15px",
                "offsetBottom": "15px",
                "offsetEnd": "15px",
                "offsetStart": "100px",
                "paddingAll": "5px",
                "cornerRadius": "4px",
                "backgroundColor": "#505050",
                "justifyContent": "center",
              }
            ],
            "paddingAll": "15px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://line.me/ti/p/~linux.1"
            }
          },
          "styles": {
            "header": {
              "backgroundColor": "#000000"
            }
          }
        }
        return data







