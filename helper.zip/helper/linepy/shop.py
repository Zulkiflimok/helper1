# -*- coding: utf-8 -*-
from akad.ttypes import GetProductRequest
import re

def loggedIn(func):
    def checkLogin(*args, **kwargs):
        if args[0].isLogin:
            return func(*args, **kwargs)
        else:
            args[0].callback.default('You must login to LINE')
    return checkLogin
    
class Shop(object):
    isLogin = False

    def __init__(self):
        self.isLogin = True
        
    @loggedIn
    def getProduct(self, packageID, language, country):
        return self.shop.getProduct(packageID, language, country)
    
    @loggedIn
    def getProductV2(self, productId = ''):
        productType = 1
        if re.findall("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", productId) != []:
            productType = 2
        elif re.findall("[0-9a-f]{24}", productId) != []:
            productType = 3
        request = GetProductRequest(productType, productId)
        return self.shop.getProductV2(request).productDetail
        
    @loggedIn
    def getActivePurchases(self, start, size, language, country):
        return self.shop.getActivePurchases(start, size, language, country)
